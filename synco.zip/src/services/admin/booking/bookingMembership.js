const {

  Booking,
  FreezeBooking,
  BookingStudentMeta,
  BookingParentMeta,
  BookingEmergencyMeta,
  BookingPayment,
  Term,
  ClassSchedule,
  Venue,
  PaymentPlan,
  Admin,
  AdminRole,
  CancelBooking,
  AppConfig,
  StarterPack,
} = require("../../../models");
const { sequelize } = require("../../../models");
const {
  validateFormData,
  isValidEmail,
} = require("../../../utils/validateFormData");
const {
  createSchedule,
  getSchedules,
  createAccessPaySuiteCustomer,
  createContract,
  createOneOffPayment
} = require("../../../utils/payment/accessPaySuit/accesPaySuit");
const generateReferralCode = require("../../../utils/generateReferralCode");
const chargeStarterPack = require("../../../utils/payment/pay360/starterPackCharge");

const axios = require("axios");
const { Op } = require("sequelize");
const bcrypt = require("bcrypt");
const { getEmailConfig } = require("../../email");
const sendEmail = require("../../../utils/email/sendEmail");
const {
  createCustomer,
  removeCustomer,
} = require("../../../utils/payment/pay360/customer");
const {
  createBillingRequest,
} = require("../../../utils/payment/pay360/payment");

function safeJsonParse(value, label = "JSON") {
  if (!value) return {};

  try {
    let parsed = value;

    // First parse if string
    if (typeof parsed === "string") {
      parsed = JSON.parse(parsed);

      // Handle double-stringified JSON
      if (typeof parsed === "string") {
        parsed = JSON.parse(parsed);
      }
    }

    // Ensure object
    return typeof parsed === "object" && parsed !== null ? parsed : {};
  } catch (error) {
    console.error(`❌ Invalid ${label}`, error, value);
    return {};
  }
}

const DEBUG = process.env.DEBUG === "true";

function generateBookingId(length = 12) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
function calculateContractStartDate(delayDays = 18) {
  const start = new Date();
  start.setDate(start.getDate() + delayDays);
  start.setHours(0, 0, 0, 0);
  return start.toISOString().split("T")[0];
}
function getNextBillingCycleDate() {
  const today = new Date();
  const next = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  return next.toISOString().split("T")[0];
}

function findMatchingSchedule(schedules) {
  if (!Array.isArray(schedules)) return null;

  return schedules.find(
    (s) => s.Name && s.Name.trim().toLowerCase() === "default schedule",
  );
}

async function autoSyncFreezeBilling() {
  const logs = [];

  try {
    const freezeBookings = await FreezeBooking.findAll({
      include: [
        {
          model: Booking,
          as: "booking", // 🔥 REQUIRED ALIAS FIX
          include: [
            {
              model: BookingPayment,
              as: "payments", // keep only if this alias exists
            },
          ],
        },
      ],
    });

    if (!freezeBookings.length) {
      return { status: true, message: "No freeze records to process" };
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const freeze of freezeBookings) {
      const booking = freeze.booking;
      if (!booking) continue;

      const payment = booking.payments?.[0] || null;

      const freezeStart = new Date(freeze.freezeStartDate);
      const reactivateOn = new Date(freeze.reactivateOn);

      const actionLog = {
        bookingId: booking.id,
        actions: [],
      };

      /* -------- FREEZE -------- */
      if (freezeStart <= today && booking.status !== "frozen") {
        await booking.update({ status: "frozen" });
        actionLog.actions.push("booking → frozen");

        if (payment?.paymentType === "accesspaysuite") {
          const gateway =
            typeof payment.gatewayResponse === "string"
              ? JSON.parse(payment.gatewayResponse)
              : payment.gatewayResponse || {};

          await payment.update({
            paymentStatus: "paused",
            gatewayResponse: {
              ...gateway,
              freeze: {
                status: "frozen",
                from: freeze.freezeStartDate,
                reason: freeze.reasonForFreezing || null,
              },
            },
          });

          actionLog.actions.push("APS payment → paused");
        }
      }

      /* ------ REACTIVATE ------ */
      if (reactivateOn <= today) {
        await booking.update({ status: "active" });
        actionLog.actions.push("booking → active");

        if (payment?.paymentType === "accesspaysuite") {
          const gateway =
            typeof payment.gatewayResponse === "string"
              ? JSON.parse(payment.gatewayResponse)
              : payment.gatewayResponse || {};

          await payment.update({
            paymentStatus: "active",
            gatewayResponse: {
              ...gateway,
              freeze: {
                ...(gateway.freeze || {}),
                status: "reactivated",
                reactivatedOn: today,
              },
            },
          });

          actionLog.actions.push("APS payment → active");
        }

        await freeze.destroy();
        actionLog.actions.push("freeze record removed");
      }

      logs.push(actionLog);
    }

    return {
      status: true,
      message: "Auto-sync billing completed",
      data: logs,
    };
  } catch (error) {
    console.error("❌ autoSyncFreezeBilling error:", error);
    return {
      status: false,
      message: "Auto-sync failed",
      error: error.message,
    };
  }
}
// GBP → pence (GoCardless only)
const gbpToPence = (amount) => Math.round(Number(amount) * 100);

function countRemainingSessionsFromTerms(startDate, terms) {
  const start = new Date(startDate);
  let totalSessions = 0;

  const safeTerms = terms || [];
  safeTerms.forEach((term) => {
    if (term.totalSessions) {
      totalSessions += term.totalSessions;
    } else if (term.sessionsMap) {
      let sessions = term.sessionsMap;

      // If it's a string (JSON from DB), parse it
      if (typeof sessions === "string") {
        try {
          sessions = JSON.parse(sessions);
        } catch (err) {
          console.error("Failed to parse term.sessionsMap:", sessions);
          sessions = [];
        }
      }

      // Ensure it's an array before filtering
      if (Array.isArray(sessions)) {
        totalSessions += sessions.filter(
          (s) => new Date(s.sessionDate) >= start
        ).length;
      } else {
        console.warn("term.sessionsMap is not an array:", sessions);
      }
    }
  });

  return totalSessions;
}
async function calculateProRata({ paymentPlan, terms, startDate }) {
  if (!paymentPlan || !terms) return 0;

  const pricePerLesson = Number(paymentPlan.priceLesson || 0);
  if (!pricePerLesson) return 0;

  // Count remaining sessions across terms
  const sessions = countRemainingSessionsFromTerms(startDate, terms);

  // ✅ Multiply pricePerLesson * remaining sessions ONLY (no students here)
  return Number((pricePerLesson * sessions).toFixed(2));
}
// 🟢 Helper: create a payment row
async function createBookingPayment({
  bookingId,
  studentId,
  parent,
  amount,
  paymentType,
  description,
  paymentCategory = "recurring",
  gatewayResponse = null,
  currency = "GBP",
  merchantId = null,
  transaction,
}) {
  return await BookingPayment.create(
    {
      bookingId,
      studentId,
      firstName: parent?.firstName || "",
      lastName: parent?.lastName || "",
      email: parent?.email || "",
      amount,
      price: amount,
      paymentType,
      description,
      paymentCategory,
      paymentStatus: gatewayResponse ? "active" : "pending",
      currency,
      merchantRef:
        gatewayResponse?.transaction?.merchantRef || `TXN-${Date.now()}`,
      gatewayResponse,
      account_holder_name: parent.account_holder_name || null,
      account_number: parent.account_number || null,
      branch_code: parent.branch_code || null,
      goCardlessCustomer: gatewayResponse?.goCardlessCustomer || null,
      goCardlessBankAccount: gatewayResponse?.goCardlessBankAccount || null,
      goCardlessBillingRequest:
        gatewayResponse?.goCardlessBillingRequest || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    { transaction },
  );
}

exports.createBooking = async (data, options) => {
  const t = await sequelize.transaction();
  try {
    let parentAdminId = null;
    const adminId = options?.adminId || null;
    const parentPortalAdminId = options?.parentAdminId || null;

    let source = "open"; // default = website

    // Parent portal MUST win
    if (parentPortalAdminId) {
      source = "parent";
    } else if (adminId) {
      source = "admin";
    }
    const leadId = options?.leadId || null;

    if (DEBUG) {
      console.log("🔍 [DEBUG] Extracted adminId:", adminId);
      console.log("🔍 [DEBUG] Extracted source:", source);
      console.log("🔍 [DEBUG] Extracted leadId:", leadId);
    }

    if (source === "parent") {
      // 👪 Parent portal → already logged in
      parentAdminId = parentPortalAdminId;
    } else if (data.parents?.length > 0) {
      const firstParent = data.parents[0];
      const email = firstParent.parentEmail?.trim()?.toLowerCase();

      if (!email) throw new Error("Parent email is required");

      const parentRole = await AdminRole.findOne({
        where: { role: "Parents" },
        transaction: t,
      });

      const hashedPassword = await bcrypt.hash("Synco123", 10);

      if (source === "admin") {
        // 👨‍💼 ADMIN → ALWAYS create new parent
        // 👨‍💼 ADMIN → Check duplicate email first
        const existingAdmin = await Admin.findOne({
          where: { email },
          transaction: t,
        });

        if (existingAdmin) {
          throw new Error("Parent with this email already exists.");
        }

        const admin = await Admin.create(
          {
            firstName: firstParent.parentFirstName || "Parent",
            lastName: firstParent.parentLastName || "",
            phoneNumber: firstParent.parentPhoneNumber || "",
            email,
            password: hashedPassword,
            roleId: parentRole.id,
            status: "active",
            referralCode: generateReferralCode(),
          },
          { transaction: t },
        );

        parentAdminId = admin.id;
      } else {
        // 🌐 WEBSITE → findOrCreate
        const [admin, isCreated] = await Admin.findOrCreate({
          where: { email },
          defaults: {
            firstName: firstParent.parentFirstName || "Parent",
            lastName: firstParent.parentLastName || "",
            phoneNumber: firstParent.parentPhoneNumber || "",
            email,
            password: hashedPassword,
            roleId: parentRole.id,
            status: "active",
            // ✅ ADD THIS
            referralCode: generateReferralCode(),
          },
          transaction: t,
        });
        // 🛡️ Safety net (old parent but referralCode missing)
        if (!isCreated && !admin.referralCode) {
          admin.referralCode = generateReferralCode();
          await admin.save({ transaction: t });
        }

        parentAdminId = admin.id;
      }
    }

    // 🔹 Determine bookedBy & source values
    let bookedBy = null;
    let bookingSource = null;

    if (source === "admin") {
      bookedBy = adminId; // ✅ admin who booked
      bookingSource = null;
    } else {
      bookedBy = null;
      bookingSource = "website";
    }

    // Create Booking
    const booking = await Booking.create(
      {
        venueId: data.venueId,
        // parentAdminId: parentAdminId,
        parentAdminId,
        bookingId: generateBookingId(12),
        leadId,
        totalStudents: data.totalStudents,
        classScheduleId: data.classScheduleId,
        startDate: data.startDate || null,
        serviceType: "weekly class membership",
        bookingType: data.paymentPlanId ? "paid" : "free",
        paymentPlanId: data.paymentPlanId || null,
        status: data.status || "active",
        bookedBy, // ✅ admin or null
        source: bookingSource, // ✅ website or null
        // bookedBy: source === "open" ? bookedByAdminId : adminId,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      { transaction: t },
    );
    if (DEBUG) {
      console.log("✅ FINAL BOOKING VALUES", {
        parentAdminId,
        bookedBy,
        source: bookingSource,
      });
    }

    // Create Students
    const studentRecords = [];
    for (const student of data.students || []) {
      const studentMeta = await BookingStudentMeta.create(
        {
          bookingTrialId: booking.id, // renamed from bookingTrialId to bookingId
          classScheduleId: student.classScheduleId, // ✅ safe
          studentFirstName: student.studentFirstName,
          studentLastName: student.studentLastName,
          dateOfBirth: student.dateOfBirth,
          age: student.age,
          gender: student.gender,
          medicalInformation: student.medicalInformation,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        { transaction: t },
      );
      studentRecords.push(studentMeta);
    }

    // Create Parents
    if (data.parents?.length && studentRecords.length) {
      const firstStudent = studentRecords[0];

      for (const parent of data.parents) {
        const email = parent.parentEmail?.trim()?.toLowerCase();
        if (!email) throw new Error("Parent email is required.");

        await BookingParentMeta.create(
          {
            studentId: firstStudent.id,
            parentFirstName: parent.parentFirstName,
            parentLastName: parent.parentLastName,
            parentEmail: email,
            parentPhoneNumber: parent.parentPhoneNumber,
            relationToChild: parent.relationToChild,
            howDidYouHear: parent.howDidYouHear,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          { transaction: t },
        );
      }
    }

    // Emergency Contact
    if (
      data.emergency?.emergencyFirstName &&
      data.emergency?.emergencyPhoneNumber &&
      studentRecords.length
    ) {
      const firstStudent = studentRecords[0];
      await BookingEmergencyMeta.create(
        {
          studentId: firstStudent.id,
          emergencyFirstName: data.emergency.emergencyFirstName,
          emergencyLastName: data.emergency.emergencyLastName,
          emergencyPhoneNumber: data.emergency.emergencyPhoneNumber,
          emergencyRelation: data.emergency.emergencyRelation,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        { transaction: t },
      );
    }

    // Update Class Capacity
    // Step 6: Update Class Capacity
    const scheduleMap = {};

    for (const s of studentRecords) {
      scheduleMap[s.classScheduleId] =
        (scheduleMap[s.classScheduleId] || 0) + 1;
    }

    for (const scheduleId of Object.keys(scheduleMap)) {
      const count = scheduleMap[scheduleId];

      const classSchedule = await ClassSchedule.findByPk(scheduleId, {
        transaction: t,
        lock: t.LOCK.UPDATE,
      });

      if (!classSchedule) throw new Error(`Schedule ${scheduleId} not found`);

      if (classSchedule.capacity < count)
        throw new Error(`Not enough capacity for schedule ${scheduleId}`);

      await classSchedule.update(
        { capacity: classSchedule.capacity - count },
        { transaction: t }
      );
    }


    await t.commit();



    /* ================= STARTER PACK FIRST ================= */

    console.log("🔥 ===== STARTER PACK FLOW START =====");

    const venueForStarter = await Venue.findByPk(data.venueId);

    console.log("🔥 booking venueId:", data.venueId);
    console.log("🔥 venue found:", !!venueForStarter);
    console.log("🔥 starterPack flag:", venueForStarter?.starterPack);

    if (venueForStarter?.starterPack) {
      console.log("🔥 Starter pack enabled for venue");

      const starterPack = await StarterPack.findOne({
        where: { enabled: true },
      });

      console.log("🔥 StarterPack record:", starterPack);

      if (!starterPack) {
        console.log("❌ No enabled starter pack found in DB");
      }

      if (starterPack && Number(starterPack.price) > 0) {
        console.log("🔥 StarterPack price:", starterPack.price);

        const parent = data.parents?.[0];

        console.log("🔥 Parent object:", parent);

        if (!parent) {
          console.log("❌ Parent missing");
          throw new Error("Parent required for starter pack");
        }

        console.log("🔥 Calling chargeStarterPack...");

        const stripeRes = await chargeStarterPack({
          name: `${parent.parentFirstName} ${parent.parentLastName}`,
          email: parent.parentEmail,
          starterPack,
        });

        console.log("🔥 Stripe Response:", stripeRes);

        if (!stripeRes?.status) {
          console.log("❌ Stripe returned failure:", stripeRes?.message);
          throw new Error(stripeRes?.message || "Starter pack payment failed");
        }

        console.log("🔥 Stripe success, saving BookingPayment...");

        await createBookingPayment({
          bookingId: booking.id,
          studentId: studentRecords[0]?.id,
          parent,
          amount: starterPack.price,
          paymentType: "stripe",
          paymentCategory: "starter_pack", // better naming
          transactionMeta: {
            paymentIntentId: stripeRes.paymentIntentId,
            status: stripeRes.raw?.status,
          },
          gatewayResponse: stripeRes.raw, // store full response
          // transaction: t
        });

        console.log("🔥 Starter pack payment saved successfully");
      } else {
        console.log("⚠️ Starter pack price invalid or 0");
      }
    }

    console.log("🔥 ===== STARTER PACK FLOW END =====");

    // Payment processing (same as your logic but fixed typo and consistency)
    if (booking.paymentPlanId && data.payment?.paymentType) {
      const venue = await Venue.findByPk(data.venueId);
      const venueOwnerAdmin = await Admin.findByPk(venue.createdBy);
      const overrideToken = venueOwnerAdmin?.GC_FRANCHISE_TOKEN || null;
      const isHQVenue = !overrideToken;
      const paymentType = isHQVenue ? "accesspaysuite" : "bank";
      if (DEBUG)
        console.log("Step 5: Start payment process, paymentType:", paymentType);

      let paymentStatusFromGateway = "pending";
      const firstStudentId = studentRecords[0]?.id;

      try {
        const paymentPlan = booking.paymentPlanId
          ? await PaymentPlan.findByPk(booking.paymentPlanId, {})
          : null;

        // ✅ Fetch effective classScheduleId from first student
        let effectiveScheduleId = null;

        // Check if data.students array exists and has at least 1 student
        if (Array.isArray(data.students) && data.students.length > 0) {
          effectiveScheduleId = data.students[0].classScheduleId;
        }

        if (!effectiveScheduleId) {
          throw new Error("Cannot determine classScheduleId: No student found");
        }

        // Fetch the ClassSchedule
        const classSchedule = await ClassSchedule.findByPk(effectiveScheduleId);

        if (!classSchedule) {
          throw new Error(
            `ClassSchedule not found for ID: ${effectiveScheduleId}`,
          );
        }

        // Safely parse termIds (DB has JSON array string)
        let termIds = [];
        if (Array.isArray(classSchedule.termIds)) {
          termIds = classSchedule.termIds;
        } else if (typeof classSchedule.termIds === "string") {
          try {
            termIds = JSON.parse(classSchedule.termIds);
          } catch (err) {
            console.error(
              "Failed to parse classSchedule.termIds:",
              classSchedule.termIds,
            );
            termIds = [];
          }
        }

        // Fetch Terms
        const terms = await Term.findAll({
          where: { id: termIds || [] },
        });


        const proRataAmount = await calculateProRata({
          paymentPlan,
          terms,
          startDate: data.startDate,
        });

        const recurringAmount = Number(paymentPlan.price || 0);

        const proRataTotal = Number(
          (proRataAmount * (data.totalStudents || 1)).toFixed(2)
        );



        // ✅ Step 2: frontend should send price only
        const frontendPrice = Number(data.payment?.price);
        console.log("FRONTEND PRICE:", frontendPrice);
        console.log("PLAN PRICE:", recurringAmount);
        console.log("PRORATA:", proRataTotal);


        if (Math.abs(frontendPrice - recurringAmount) > 0.01) {
          return {
            status: false,
            message: `Plan price mismatch. Frontend: ${frontendPrice}, Backend: ${recurringAmount}`,
          };
        }

        console.log("✅ Price matches frontend and backend");

        const merchantRef = `TXN-${Math.floor(1000 + Math.random() * 9000)}`;

        let gatewayResponse = null;
        let goCardlessCustomer = null;
        let goCardlessBankAccount = null;
        let goCardlessBillingRequest = null;
        // const paymentType = isHQVenue ? "accesspaysuite" : "bank";

        if (paymentType === "bank") {
          // ✅ Prepare GoCardless payload
          const customerPayload = {
            email: data.payment.email || data.parents?.[0]?.parentEmail || "",
            given_name: data.payment.firstName || "",
            family_name: data.payment.lastName || "",
            address_line1: data.payment.addressLine1 || "",
            city: data.payment.city || "",
            postal_code: data.payment.postalCode || "",
            country_code: data.payment.countryCode || "GB",
            currency: data.payment.currency || "GBP",
            account_holder_name: data.payment.account_holder_name || "",
            account_number: data.payment.account_number || "",
            branch_code: data.payment.branch_code || "",
          };

          const createCustomerRes = await createCustomer(customerPayload, overrideToken);
          if (!createCustomerRes.status)
            throw new Error(
              createCustomerRes.message ||
              "Failed to create GoCardless customer.",
            );

          if (proRataTotal > 0) {
            if (!isHQVenue) {
              /* -------- Franchisee → GoCardless -------- */

              const gcRes = await createBillingRequest({
                customerId: createCustomerRes.customer.id,
                description: "Pro-rata lesson charge",
                amount: gbpToPence(proRataTotal),
              }, overrideToken);

              await createBookingPayment({
                bookingId: booking.id,
                studentId: firstStudentId,
                parent: data.parents?.[0],
                amount: proRataTotal,
                paymentType: "bank",
                paymentCategory: "pro_rata",
                gatewayResponse: gcRes,
              },
                // { transaction: t }
              );
            }

          }

          const billingRequestPayload = {
            customerId: createCustomerRes.customer.id,
            description: `${venue?.name || "Venue"} - ${classSchedule?.className || "Class"
              }`,
            // amount: planPrice, // ✅ use plan price
            // amount: payloadPrice, // ✅ FROM PAYLOAD
            amount: gbpToPence(recurringAmount),
            scheme: "faster_payments",
            currency: "GBP",
            reference: `TRX-${Date.now()}-${Math.floor(
              1000 + Math.random() * 9000,
            )}`,
            mandateReference: `MD-${Date.now()}-${Math.floor(
              1000 + Math.random() * 9000,
            )}`,
            metadata: { crm_id: customerPayload.crm_id },
            fallbackEnabled: true,
          };

          const createBillingRequestRes = await createBillingRequest(
            billingRequestPayload,
            overrideToken
          );
          if (!createBillingRequestRes.status) {
            await removeCustomer(createCustomerRes.customer.id, overrideToken);
          }

          goCardlessCustomer = createCustomerRes.customer;
          goCardlessBankAccount = createCustomerRes.bankAccount;
          goCardlessBillingRequest = {
            ...createBillingRequestRes.billingRequest,
            // planPrice,
            price: recurringAmount,
          };

          gatewayResponse = {
            gateway: "gocardless",
            goCardlessCustomer,
            goCardlessBankAccount,
            goCardlessBillingRequest,
          };
        } else if (paymentType === "accesspaysuite") {
          if (DEBUG) console.log("🔁 Processing Access PaySuite recurring payment");

          const schedulesRes = await getSchedules();
          if (!schedulesRes.status) {
            throw new Error("Access PaySuite: Failed to fetch schedules");
          }

          const services = schedulesRes.data?.Services || [];
          const schedules = services.flatMap(service => service.Schedules || []);

          let matchedSchedule = findMatchingSchedule(schedules, paymentPlan);

          if (!matchedSchedule) {
            throw new Error(
              `Access PaySuite: Schedule "Default Schedule" not found. Please create this schedule in APS dashboard before proceeding.`
            );
          }

          const scheduleId = matchedSchedule.ScheduleId;

          const customerPayload = {
            email: data.payment?.email || data.parents?.[0]?.parentEmail,
            title: "Mr",
            customerRef: `BOOK-${booking.id}-${Date.now()}`,
            firstName: data.payment?.firstName || data.parents?.[0]?.parentFirstName,
            surname: data.payment?.lastName || data.parents?.[0]?.parentLastName,
            line1: data.payment?.addressLine1 || "10 Downing Street",
            postCode: data.payment?.postalCode || "SW1A 2AA",
            accountNumber: data.payment?.account_number,
            bankSortCode: data.payment?.branch_code,
            accountHolderName:
              data.payment?.account_holder_name ||
              `${data.parents?.[0]?.parentFirstName} ${data.parents?.[0]?.parentLastName}`,
          };

          const customerRes = await createAccessPaySuiteCustomer(customerPayload);
          if (!customerRes.status) {
            throw new Error(customerRes.message);   // ✅ gateway ka exact message
          }
          console.log("APS CREATE CUSTOMER RESPONSE:", customerRes);
          const customerId =
            customerRes.data?.CustomerId ||
            customerRes.data?.Id ||
            customerRes.data?.customerId ||
            customerRes.data?.id;

          if (!customerId) throw new Error("Access PaySuite: Customer ID missing");

          // ================= PRO-RATA CONTRACT =================
          if (proRataTotal > 0) {
            console.log("🔥 APS PRO RATA:", proRataTotal);

            const proRataContractStartDate = calculateContractStartDate(18);
            const proRataContractPayload = {
              scheduleName: matchedSchedule.Name,
              start: proRataContractStartDate,
              isGiftAid: false,
              terminationType: paymentPlan.duration ? "Fixed term" : "Until further notice",
              atTheEnd: "Switch to further notice",
              InitialAmount: proRataTotal,
            };
            if (paymentPlan.duration) {
              const start = new Date(proRataContractStartDate);
              const end = new Date(start);
              end.setMonth(end.getMonth() + Number(paymentPlan.duration));
              proRataContractPayload.TerminationDate = end.toISOString().split("T")[0];
            }

            const proRataContractRes = await createContract(customerId, proRataContractPayload);
            if (!proRataContractRes.status)
              throw new Error("Access PaySuite: Pro-rata contract creation failed");

            // Save PRO-RATA as separate BookingPayment row
            await BookingPayment.create({
              bookingId: booking.id,
              paymentPlanId: booking.paymentPlanId,
              studentId: firstStudentId,
              paymentType: "accesspaysuite",
              paymentCategory: "pro_rata",
              firstName: data.payment?.firstName || data.parents?.[0]?.parentFirstName || "",
              lastName: data.payment?.lastName || data.parents?.[0]?.parentLastName || "",
              email: data.payment?.email || data.parents?.[0]?.parentEmail || "",
              amount: proRataTotal,
              price: proRataTotal,
              billingAddress: data.payment?.billingAddress || "",
              account_number: data.payment?.account_number || "",
              branch_code: data.payment?.branch_code || "",
              account_holder_name: data.payment?.account_holder_name || "",
              paymentStatus: "active",
              currency: "GBP",
              merchantRef: `PR-${booking.id}-${Date.now()}`,
              description: `${venue?.name || "Venue"} - ${classSchedule?.className || "Class"} (Pro-rata)`,
              commerceType: "ECOM",
              gatewayResponse: {
                gateway: "accesspaysuite",
                schedule: matchedSchedule,
                customer: customerRes.data,
                contract: proRataContractRes.data,
              },
              transactionMeta: { status: "active" },
              goCardlessCustomer: null,
              goCardlessBankAccount: null,
              goCardlessBillingRequest: null,
              createdAt: new Date(),
              updatedAt: new Date(),
              // transaction: t
            });

            console.log("✅ APS pro-rata row saved same as recurring");
          }

          // ================= RECURRING CONTRACT =================
          // const recurringContractStartDate = calculateContractStartDate(18);
          const recurringContractStartDate = calculateContractStartDate(18);
          const recurringContractPayload = {
            scheduleName: matchedSchedule.Name,
            start: recurringContractStartDate,
            isGiftAid: false,
            terminationType: paymentPlan.duration ? "Fixed term" : "Until further notice",
            atTheEnd: "Switch to further notice",
          };
          if (paymentPlan.duration) {
            const start = new Date(recurringContractStartDate);
            const end = new Date(start);
            end.setMonth(end.getMonth() + Number(paymentPlan.duration));
            recurringContractPayload.TerminationDate = end.toISOString().split("T")[0];
          }

          console.log("APS Recurring Contract Payload:", recurringContractPayload);

          const recurringContractRes = await createContract(customerId, recurringContractPayload);
          if (!recurringContractRes.status)
            throw new Error("Access PaySuite: Recurring contract creation failed");

          gatewayResponse = {
            gateway: "accesspaysuite",
            schedule: matchedSchedule,
            customer: customerRes.data,
            contract: recurringContractRes.data,
          };

          paymentStatusFromGateway = "active";
        }

        // Save BookingPayment
        await BookingPayment.create({
          bookingId: booking.id,
          paymentPlanId: booking.paymentPlanId,
          studentId: firstStudentId,
          paymentType,
          paymentCategory: "recurring",
          firstName:
            data.payment.firstName || data.parents?.[0]?.parentFirstName || "",
          lastName:
            data.payment.lastName || data.parents?.[0]?.parentLastName || "",
          email: data.payment.email || data.parents?.[0]?.parentEmail || "",
          amount: recurringAmount, // plan + pro-rata
          price: recurringAmount, // plan + pro-rata
          billingAddress: data.payment.billingAddress || "",
          account_number: data.payment.account_number || "",
          branch_code: data.payment.branch_code || "",
          account_holder_name: data.payment.account_holder_name || "",
          paymentStatus: paymentStatusFromGateway,
          currency: gatewayResponse?.transaction?.currency || "GBP",
          merchantRef: gatewayResponse?.transaction?.merchantRef || merchantRef,
          description:
            gatewayResponse?.transaction?.description ||
            `${venue?.name || "Venue"} - ${classSchedule?.className || "Class"}`,
          commerceType: "ECOM",
          gatewayResponse,
          transactionMeta: {
            status: gatewayResponse?.transaction?.status || "pending",
          },
          goCardlessCustomer: gatewayResponse?.goCardlessCustomer || null,
          goCardlessBankAccount: gatewayResponse?.goCardlessBankAccount || null,
          goCardlessBillingRequest:
            gatewayResponse?.goCardlessBillingRequest || null,
          createdAt: new Date(),
          updatedAt: new Date(),
          // transaction: t
        });

        if (paymentStatusFromGateway === "failed")
          throw new Error("Payment failed. Booking not created.");

        if (DEBUG) {
          console.log(
            "🔍 [DEBUG] Payment processed with status:",
            paymentStatusFromGateway,
          );
        }
      } catch (error) {
        if (!t.finished) await t.rollback();
        return { status: false, message: error.message };
      }
    }



    return {
      status: true,
      data: {
        bookingId: booking.bookingId,
        booking,
        studentId: studentRecords[0]?.id,
        studentFirstName: studentRecords[0]?.studentFirstName,
        studentLastName: studentRecords[0]?.studentLastName,
      },
    };
  } catch (error) {
    await t.rollback();
    return { status: false, message: error.message };
  }
};

exports.getAllBookingsWithStats = async (filters = {}) => {
  await autoSyncFreezeBilling();

  try {
    if (filters.bookedBy !== undefined) {
      allowedAdminIds = Array.isArray(filters.bookedBy)
        ? filters.bookedBy.map(Number)
        : [Number(filters.bookedBy)];
    }
    // ----------------------------
    // ✅ ACCESS CONTROL
    // ----------------------------
    let accessControl = {};

    if (filters.bookedBy && filters.bookedBy.adminIds?.length > 0) {
      const { type, adminIds } = filters.bookedBy;

      // ------------------------------------
      // SUPER ADMIN
      // ------------------------------------
      if (type === "super_admin") {
        accessControl = {
          [Op.or]: [
            // 1️⃣ Admin bookings → self + child admins
            {
              bookedBy: { [Op.in]: adminIds },
            },

            // 2️⃣ Website bookings → ONLY venues created by THIS super admin
            {
              bookedBy: null,
              source: "website",
              "$students.classSchedule.venue.createdBy$": {
                [Op.in]: adminIds,
              },
            },
          ],
        };
      }

      // ------------------------------------
      // ADMIN
      // ------------------------------------
      else if (type === "admin") {
        accessControl = {
          [Op.or]: [
            // 1️⃣ Admin bookings → self + super admin
            {
              bookedBy: { [Op.in]: adminIds },
            },

            // 2️⃣ Website bookings → admin venues + super admin venues
            {
              bookedBy: null,
              source: "website",
              "$students.classSchedule.venue.createdBy$": {
                [Op.in]: adminIds,
              },
            },
          ],
        };
      }

      // ------------------------------------
      // AGENT
      // ------------------------------------
      else {
        accessControl = {
          bookedBy: { [Op.in]: adminIds },
        };
      }
    }
    // const whereBooking = { bookingType: "paid" };
    const whereBooking = {
      bookingType: {
        [Op.in]: ["paid", "waiting list", "removed"],
      },
      status: {
        [Op.in]: [
          "cancelled",
          "active",
          "frozen",
          "waiting list",
          "request_to_cancel",
          "rebooked",
          "removed",
          "attended",
          "not attended",
          "assigned",
        ],
      },

      [Op.and]: [
        // ✅ Waiting list rule
        {
          [Op.or]: [
            { status: { [Op.ne]: "waiting list" } },
            {
              status: "waiting list",
              paymentPlanId: { [Op.not]: null },
            },
          ],
        },

        // ✅ ACCESS CONTROL (admins + website bookings)
        accessControl,
      ],
    };

    const whereVenue = {};

    console.log(`filters - `, filters);
    if (filters.fromDate) filters.dateFrom = filters.fromDate;
    if (filters.toDate) filters.dateTo = filters.toDate;
    // 🔹 Filters
    // if (filters.status) whereBooking.status = filters.status;
    if (filters.status) {
      whereBooking.status = Array.isArray(filters.status)
        ? { [Op.in]: filters.status }
        : filters.status;
    }

    if (filters.venueId) whereBooking.venueId = filters.venueId;
    if (filters.venueName)
      whereVenue.name = { [Op.like]: `%${filters.venueName}%` };

    if (filters.duration) {
      const raw = filters.duration.toLowerCase().trim();

      const match = raw.match(/^(\d+)\s*(months?|weeks?|days?)$/);

      if (match) {
        const durationValue = match[1];
        const intervalValue = match[2];

        whereBooking["$paymentPlan.duration$"] = durationValue;
        whereBooking["$paymentPlan.interval$"] = {
          [Op.like]: `%${intervalValue}%`,
        };
      } else {
        whereBooking["$paymentPlan.duration$"] = {
          [Op.like]: `%${raw}%`,
        };
      }
    }

    // ✅ Date filters
    if (filters.fromDate) filters.dateFrom = filters.fromDate;
    if (filters.toDate) filters.dateTo = filters.toDate;

    // Date filters
    if (filters.dateBooked) {
      const start = new Date(`${filters.dateBooked} 00:00:00`);
      const end = new Date(`${filters.dateBooked} 23:59:59`);
      whereBooking.createdAt = { [Op.between]: [start, end] };
    } else if (filters.dateFrom && filters.dateTo) {
      const start = new Date(`${filters.dateFrom} 00:00:00`);
      const end = new Date(`${filters.dateTo} 23:59:59`);
      whereBooking.createdAt = { [Op.between]: [start, end] };
    } else if (filters.dateFrom) {
      const start = new Date(`${filters.dateFrom} 00:00:00`);
      whereBooking.createdAt = { [Op.gte]: start };
    } else if (filters.dateTo) {
      const end = new Date(`${filters.dateTo} 23:59:59`);
      whereBooking.createdAt = { [Op.lte]: end };
    }

    const bookings = await Booking.findAll({
      where: {
        ...whereBooking, // spread the filters correctly
        // serviceType: "weekly class membership",
        serviceType: {
          [Op.in]: ["weekly class membership", "weekly class trial"], // ✅ both types
        },
      },
      order: [["id", "DESC"]],
      include: [
        {
          model: BookingStudentMeta,
          as: "students",
          include: [
            {
              model: ClassSchedule,
              as: "classSchedule",
              include: [
                {
                  model: Venue,
                  as: "venue",
                  where: filters.venueName
                    ? { name: { [Op.like]: `%${filters.venueName}%` } }
                    : undefined,
                  required: !!filters.venueName,
                },
              ],
            },
            { model: BookingParentMeta, as: "parents", required: false },
            {
              model: BookingEmergencyMeta,
              as: "emergencyContacts",
              required: false,
            },
          ],
          required: false,
        },
        { model: BookingPayment, as: "payments", required: false },
        { model: PaymentPlan, as: "paymentPlan", required: false },
        {
          model: Admin,
          as: "bookedByAdmin",
          attributes: [
            "id",
            "firstName",
            "lastName",
            "email",
            "roleId",
            "status",
            "profile",
          ],
          required: false,
        },
        {
          model: Admin,
          as: "assignedAgent", // 👈 alias for the assigned agent
          attributes: [
            "id",
            "firstName",
            "lastName",
            "email",
            "roleId",
            "status",
          ],
          required: false,
        },
      ],
    });

    const parsedBookings = await Promise.all(
      bookings.map(async (booking) => {
        // Students
        const students =
          booking.students?.map((s) => ({
            studentFirstName: s.studentFirstName,
            studentLastName: s.studentLastName,
            dateOfBirth: s.dateOfBirth,
            age: s.age,
            gender: s.gender,
            medicalInformation: s.medicalInformation,
            classScheduleId: s.classScheduleId,
            // ✅ student-wise class schedule
            classSchedule: s.classSchedule
              ? {
                id: s.classSchedule.id,
                className: s.classSchedule.className,
                startTime: s.classSchedule.startTime,
                endTime: s.classSchedule.endTime,
              }
              : null,
          })) || [];

        // Parents (flatten all student parents)
        const parents =
          booking.students?.flatMap(
            (s) =>
              s.parents?.map((p) => ({
                parentFirstName: p.parentFirstName,
                parentLastName: p.parentLastName,
                parentEmail: p.parentEmail,
                parentPhoneNumber: p.parentPhoneNumber,
                relationToChild: p.relationToChild,
                howDidYouHear: p.howDidYouHear,
              })) || [],
          ) || [];

        // Emergency contacts (take first one per student)
        // ✅ Pick only the first student's emergency contacts
        const emergency =
          booking.students?.[0]?.emergencyContacts?.map((e) => ({
            emergencyFirstName: e.emergencyFirstName,
            emergencyLastName: e.emergencyLastName,
            emergencyPhoneNumber: e.emergencyPhoneNumber,
            emergencyRelation: e.emergencyRelation,
          })) || [];

        // Venue & plan
        const venue = booking.students?.[0]?.classSchedule?.venue || null;

        const plan = booking.paymentPlan || null;

        const payment = booking.payments?.[0] || null;
        const paymentPlans = plan ? [plan] : [];

        // PaymentData with parsed gatewayResponse & transactionMeta
        const parsedGatewayResponse = safeJsonParse(
          payment?.gatewayResponse,
          "gatewayResponse",
        );

        const parsedTransactionMeta = safeJsonParse(
          payment?.transactionMeta,
          "transactionMeta",
        );

        const parsedGoCardlessBillingRequest = safeJsonParse(
          payment?.goCardlessBillingRequest,
          "goCardlessBillingRequest",
        );

        const paymentData = payment
          ? {
            id: payment.id,
            bookingId: payment.bookingId,
            firstName: payment.firstName,
            lastName: payment.lastName,
            email: payment.email,
            billingAddress: payment.billingAddress,
            cardHolderName: payment.cardHolderName,
            cv2: payment.cv2,
            expiryDate: payment.expiryDate,
            paymentType: payment.paymentType,
            // pan: payment.pan,
            paymentStatus: payment.paymentStatus,
            referenceId: payment.referenceId,
            currency: payment.currency,
            merchantRef: payment.merchantRef,
            description: payment.description,
            commerceType: payment.commerceType,
            createdAt: payment.createdAt,
            updatedAt: payment.updatedAt,
            goCardlessBillingRequest: parsedGoCardlessBillingRequest,
            gatewayResponse: parsedGatewayResponse,
            transactionMeta: parsedTransactionMeta,
            totalCost: plan ? plan.price + (plan.joiningFee || 0) : 0,
          }
          : null;

        const { venue: _venue, ...bookingData } = booking.dataValues;

        return {
          ...bookingData,
          students,
          parents,
          emergency,
          venue,
          // payments: booking.payments || [],
          paymentPlan: booking.paymentPlan || null,
          paymentPlans,
          paymentData,
          bookedByAdmin: booking.bookedByAdmin || null,
          assignedAgent: booking.assignedAgent || null, // 👈 agent info
        };
      }),
    );

    const allBookingsForStats = [...parsedBookings]; // ✅ ADD THIS

    // Student filter
    let finalBookings = parsedBookings;
    if (filters.studentName) {
      const keyword = filters.studentName.toLowerCase().trim();
      finalBookings = finalBookings
        .map((b) => {
          const matchedStudents = b.students.filter((s) => {
            const firstName = s.studentFirstName?.toLowerCase() || "";
            const lastName = s.studentLastName?.toLowerCase() || "";
            const fullName = `${firstName} ${lastName}`.trim();

            return (
              firstName.includes(keyword) ||
              lastName.includes(keyword) ||
              fullName.includes(keyword)
            );
          });

          if (matchedStudents.length > 0) {
            return {
              ...b,
              students: matchedStudents,
            };
          }
          return null;
        })
        .filter(Boolean);

      if (finalBookings.length === 0) {
        return {
          status: true,
          message: "No bookings found for the student.",
          totalPaidBookings: 0,
          data: { membership: [], venue: [], bookedByAdmins: [] },
          stats: {
            totalStudents: 0,
            totalRevenue: 0,
            avgMonthlyFee: 0,
            avgLifeCycle: 0,
          },
        };
      }
    }

    // Venue filter
    if (filters.venueName) {
      const keyword = filters.venueName.toLowerCase();
      finalBookings = finalBookings.filter((b) =>
        b.venue?.name?.toLowerCase().includes(keyword),
      );
      if (finalBookings.length === 0) {
        return {
          status: true,
          message: "No bookings found for the venue.",
          totalPaidBookings: 0,
          data: { membership: [], venue: [], bookedByAdmins: [] },
          stats: {
            totalStudents: 0,
            totalRevenue: 0,
            avgMonthlyFee: 0,
            avgLifeCycle: 0,
          },
        };
      }
    }

    // Collect unique venues
    const venueMap = {};
    bookings.forEach((b) => {
      if (b.classSchedule?.venue) {
        venueMap[b.classSchedule.venue.id] = b.classSchedule.venue;
      }
    });
    const allVenues = Object.values(venueMap);

    // Collect unique bookedByAdmins
    const adminMap = {};
    bookings.forEach((b) => {
      if (b.bookedByAdmin) {
        adminMap[b.bookedByAdmin.id] = b.bookedByAdmin;
      }
    });
    const allAdmins = Object.values(adminMap);

    const calculatePercentageChange = (current, previous) => {
      if (!previous || previous === 0) {
        return current > 0 ? 100 : 0; // first-time growth
      }

      return Math.round(((current - previous) / previous) * 100);
    };

    const now = new Date();
    const currentYearStart = new Date(now.getFullYear(), 0, 1);
    const currentYearEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59);

    const previousYearStart = new Date(now.getFullYear() - 1, 0, 1);
    const previousYearEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59);
    const currentYearBookings = allBookingsForStats.filter(
      (b) =>
        new Date(b.createdAt) >= currentYearStart &&
        new Date(b.createdAt) <= currentYearEnd,
    );

    const previousYearBookings = allBookingsForStats.filter(
      (b) =>
        new Date(b.createdAt) >= previousYearStart &&
        new Date(b.createdAt) <= previousYearEnd,
    );

    // Stats
    const calculateStats = (bookings) => {
      const totalStudents = bookings.reduce(
        (acc, b) => acc + (b.students?.length || 0),
        0,
      );

      const totalRevenue = bookings.reduce((acc, b) => {
        const plan = b.paymentPlans?.[0];
        if (plan?.price != null) {
          const studentsCount = b.students?.length || 1;
          return acc + (plan.price + (plan.joiningFee || 0)) * studentsCount;
        }
        return acc;
      }, 0);

      const avgMonthlyFee =
        bookings.reduce((acc, b) => {
          const plan = b.paymentPlans?.[0];
          if (plan?.duration && plan.price != null) {
            const studentsCount = b.students?.length || 1;
            return (
              acc +
              ((plan.price + (plan.joiningFee || 0)) / plan.duration) *
              studentsCount
            );
          }
          return acc;
        }, 0) / (totalStudents || 1);

      const avgLifeCycle =
        bookings.reduce((acc, b) => {
          const plan = b.paymentPlans?.[0];
          if (plan?.duration != null) {
            const studentsCount = b.students?.length || 1;
            return acc + plan.duration * studentsCount;
          }
          return acc;
        }, 0) / (totalStudents || 1);

      return {
        totalStudents,
        totalRevenue,
        avgMonthlyFee: Math.round(avgMonthlyFee * 100) / 100,
        avgLifeCycle: Math.round(avgLifeCycle * 100) / 100,
      };
    };
    const currentStats = calculateStats(currentYearBookings);
    const previousStats = calculateStats(previousYearBookings);

    const stats = {
      totalStudents: {
        totalStudents: currentStats.totalStudents,
        percentage: calculatePercentageChange(
          currentStats.totalStudents,
          previousStats.totalStudents,
        ),
      },
      totalRevenue: {
        totalRevenue: currentStats.totalRevenue,
        percentage: calculatePercentageChange(
          currentStats.totalRevenue,
          previousStats.totalRevenue,
        ),
      },
      avgMonthlyFee: {
        avgMonthlyFee: currentStats.avgMonthlyFee,
        percentage: calculatePercentageChange(
          currentStats.avgMonthlyFee,
          previousStats.avgMonthlyFee,
        ),
      },
      avgLifeCycle: {
        avgLifeCycle: currentStats.avgLifeCycle,
        percentage: calculatePercentageChange(
          currentStats.avgLifeCycle,
          previousStats.avgLifeCycle,
        ),
      },
    };

    // ✅ New: Fetch all venues from DB (including those with no bookings)
    // ✅ Collect venues only from filtered bookings (hierarchy safe)
    const venueMapFiltered = {};

    finalBookings.forEach((b) => {
      if (b.venue?.id) {
        venueMapFiltered[b.venue.id] = b.venue;
      }
    });

    const allowedVenues = Object.values(venueMapFiltered).sort((a, b) =>
      (a.name || "").localeCompare(b.name || ""),
    );

    return {
      status: true,
      message: "Paid bookings retrieved successfully",
      totalPaidBookings: finalBookings.length,
      data: {
        membership: finalBookings,
        venue: allowedVenues,
        allVenues: allowedVenues,
        bookedByAdmins: allAdmins, // ✅ unique list of admins like venues
      },
      stats,
    };
  } catch (error) {
    console.error("❌ getAllBookingsWithStats Error:", error.message);
    return { status: false, message: error.message };
  }
};

exports.getActiveMembershipBookings = async (filters = {}) => {
  await autoSyncFreezeBilling();

  try {
    console.log("🔹 Service start: getActiveMembershipBookings");
    console.log("🔹 Filters received in service:", filters);

    // ✅ Default filter: active + paid bookings
    // const whereBooking = { bookingType: "paid", status: "active" };
    const whereBooking = {
      bookingType: "paid",
      status: filters.status || "active",
    };

    const whereVenue = {};

    // 🔹 Apply filters
    if (filters.venueId) whereBooking.venueId = filters.venueId;
    if (filters.venueName)
      whereVenue.name = { [Op.like]: `%${filters.venueName}%` };

    if (filters.duration) {
      const raw = filters.duration.toLowerCase().trim();

      const match = raw.match(/^(\d+)\s*(months?|weeks?|days?)$/);

      if (match) {
        const durationValue = match[1];
        const intervalValue = match[2];

        whereBooking["$paymentPlan.duration$"] = durationValue;
        whereBooking["$paymentPlan.interval$"] = {
          [Op.like]: `%${intervalValue}%`,
        };
      } else {
        whereBooking["$paymentPlan.duration$"] = {
          [Op.like]: `%${raw}%`,
        };
      }
    }

    if (filters.bookedBy) {
      // Ensure bookedBy is always an array
      const bookedByArray = Array.isArray(filters.bookedBy)
        ? filters.bookedBy
        : [filters.bookedBy];

      whereBooking.bookedBy = { [Op.in]: bookedByArray };
    }
    if (filters.dateBooked) {
      const start = new Date(filters.dateBooked + " 00:00:00");
      const end = new Date(filters.dateBooked + " 23:59:59");
      whereBooking.createdAt = { [Op.between]: [start, end] };
    }
    if (filters.planType) {
      whereBooking["$paymentPlan.duration$"] = {
        [Op.like]: `%${filters.planType}%`,
      };
    }

    if (filters.studentName) {
      const keyword = filters.studentName.toLowerCase().trim();

      // ✅ Handles first name, last name, or full name (e.g., "akshay kumar")
      whereBooking[Op.or] = [
        { "$students.studentFirstName$": { [Op.like]: `%${keyword}%` } },
        { "$students.studentLastName$": { [Op.like]: `%${keyword}%` } },
        {
          [Op.and]: [
            {
              "$students.studentFirstName$": {
                [Op.ne]: null,
              },
            },
            {
              "$students.studentLastName$": {
                [Op.ne]: null,
              },
            },
            sequelize.where(
              sequelize.fn(
                "LOWER",
                sequelize.fn(
                  "CONCAT",
                  sequelize.col("students.studentFirstName"),
                  " ",
                  sequelize.col("students.studentLastName"),
                ),
              ),
              {
                [Op.like]: `%${keyword}%`,
              },
            ),
          ],
        },
      ];
    }
    const now = new Date();
    const currentYearStart = new Date(now.getFullYear(), 0, 1);
    const currentYearEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59);

    // If no explicit date filter → default to current year
    if (!filters.fromDate && !filters.toDate && !filters.dateBooked) {
      whereBooking.createdAt = {
        [Op.between]: [currentYearStart, currentYearEnd],
      };
    }

    // ✅ Date filters
    if (filters.dateBooked) {
      const start = new Date(filters.dateBooked + " 00:00:00");
      const end = new Date(filters.dateBooked + " 23:59:59");
      whereBooking.createdAt = { [Op.between]: [start, end] };
    } else if (filters.fromDate && filters.toDate) {
      const start = new Date(filters.fromDate + " 00:00:00");
      const end = new Date(filters.toDate + " 23:59:59");
      whereBooking.createdAt = { [Op.between]: [start, end] };
    } else if (filters.dateFrom && filters.dateTo) {
      const start = new Date(filters.dateFrom + " 00:00:00");
      const end = new Date(filters.dateTo + " 23:59:59");
      whereBooking.startDate = { [Op.between]: [start, end] };
    } else if (filters.fromDate) {
      const start = new Date(filters.fromDate + " 00:00:00");
      whereBooking.createdAt = { [Op.gte]: start };
    } else if (filters.toDate) {
      const end = new Date(filters.toDate + " 23:59:59");
      whereBooking.createdAt = { [Op.lte]: end };
    }

    console.log("🔹 whereBooking:", whereBooking);

    // 🔹 Fetch bookings
    const bookings = await Booking.findAll({
      where: {
        ...whereBooking, // spread the filters correctly
        serviceType: "weekly class membership",
      },
      // where: whereBooking,
      order: [["id", "DESC"]],
      include: [
        {
          model: BookingStudentMeta,
          as: "students",
          include: [
            {
              model: ClassSchedule,
              as: "classSchedule",
              // include: [
              //   {
              //     model: Venue, as: "venue", where: filters.venueName
              //       ? { name: { [Op.like]: `%${filters.venueName}%` } }
              //       : undefined,
              //     required: !!filters.venueName,
              //   },
              // ],
            },
            { model: BookingParentMeta, as: "parents", required: false },
            {
              model: BookingEmergencyMeta,
              as: "emergencyContacts",
              required: false,
            },
          ],
          required: true,
        },
        // ✅ YEH NAYA ADD KIYA
        {
          model: Venue,
          as: "venue",
          where: filters.venueName
            ? { name: { [Op.like]: `%${filters.venueName}%` } }
            : undefined,
          required: !!filters.venueName,
        },
        { model: BookingPayment, as: "payments", required: false },
        {
          model: PaymentPlan,
          as: "paymentPlan",
          required: false,
          attributes: [
            "id",
            "title",
            "price",
            "joiningFee",
            "duration",
            "interval",
          ],
        },
        { model: Admin, as: "admin", required: false },
      ],
    });

    console.log("🔹 Bookings fetched:", bookings.length);

    // 🔹 Map bookings to memberShipSales
    const memberShipSales = bookings.map((booking) => {
      // const venue = booking.classSchedule?.venue || {};
      // Get venue from the first student's classSchedule
      const venue = booking.venue || null;
      const payment = booking.payments?.[0] || {};
      const plan = booking.paymentPlan || null;

      // Students
      const students =
        booking.students?.map((student) => ({
          studentFirstName: student.studentFirstName,
          studentLastName: student.studentLastName,
          dateOfBirth: student.dateOfBirth,
          age: student.age,
          gender: student.gender,
          medicalInformation: student.medicalInformation,
          classScheduleId: student.classScheduleId,
          // ✅ student-wise class schedule
          classSchedule: student.classSchedule
            ? {
              id: student.classSchedule.id,
              className: student.classSchedule.className,
              startTime: student.classSchedule.startTime,
              endTime: student.classSchedule.endTime,
            }
            : null,
        })) || [];

      // Parents
      const parents =
        booking.students?.flatMap(
          (student) =>
            student.parents?.map((parent) => ({
              parentFirstName: parent.parentFirstName,
              parentLastName: parent.parentLastName,
              parentEmail: parent.parentEmail,
              parentPhoneNumber: parent.parentPhoneNumber,
              relationToChild: parent.relationToChild,
              howDidYouHear: parent.howDidYouHear,
            })) || [],
        ) || [];

      // Emergency
      const emergency =
        booking.students?.flatMap((student) =>
          student.emergencyContacts?.map((em) => ({
            emergencyFirstName: em.emergencyFirstName,
            emergencyLastName: em.emergencyLastName,
            emergencyPhoneNumber: em.emergencyPhoneNumber,
            emergencyRelation: em.emergencyRelation,
          })),
        )?.[0] || null;

      // Payment
      let parsedGatewayResponse = {};
      let parsedTransactionMeta = {};

      parsedGatewayResponse = safeJsonParse(
        payment?.gatewayResponse,
        "gatewayResponse",
      );

      parsedTransactionMeta = safeJsonParse(
        payment?.transactionMeta,
        "transactionMeta",
      );

      // Combine all payment info into a fully structured object
      const paymentData = payment
        ? {
          id: payment.id,
          bookingId: payment.bookingId,
          firstName: payment.firstName,
          lastName: payment.lastName,
          email: payment.email,
          billingAddress: payment.billingAddress,
          cardHolderName: payment.cardHolderName,
          cv2: payment.cv2,
          expiryDate: payment.expiryDate,
          paymentType: payment.paymentType,
          // pan: payment.pan,
          paymentStatus: payment.paymentStatus,
          referenceId: payment.referenceId,
          currency: payment.currency,
          merchantRef: payment.merchantRef,
          description: payment.description,
          commerceType: payment.commerceType,
          createdAt: payment.createdAt,
          updatedAt: payment.updatedAt,
          gatewayResponse: parsedGatewayResponse, // fully parsed JSON
          transactionMeta: parsedTransactionMeta, // fully parsed JSON
          totalCost: plan ? plan.price + (plan.joiningFee || 0) : 0,
        }
        : null;

      return {
        bookingId: booking.id,
        status: booking.status,
        startDate: booking.startDate,
        dateBooked: booking.createdAt,
        venueId: booking.venueId,

        // Full classSchedule + venue
        // classSchedule: booking.classSchedule || null,
        // venue: venue || null,

        bookedBy: booking.admin
          ? {
            id: booking.admin.id,
            firstName: booking.admin.firstName,
            lastName: booking.admin.lastName,
            email: booking.admin.email,
            role: booking.admin.role,
          }
          : null,

        // totalStudents: students.length,
        students,
        parents,
        emergency,
        venue,

        paymentPlanData: plan
          ? {
            id: plan.id,
            title: plan.title,
            price: plan.price,
            joiningFee: plan.joiningFee,
            duration: plan.duration,
            interval: plan.interval,
          }
          : null,

        payment: paymentData,
      };
    });

    // -------------------------------
    // Collect all unique venues (from all students)
    // -------------------------------
    const venueMap = {};
    bookings.forEach((booking) => {
      if (booking.venue && booking.venue.id) {
        venueMap[booking.venue.id] = booking.venue;
      }
    });
    const allVenues = Object.values(venueMap);

    // -------------------------------
    // Collect all unique bookedByAdmins
    // -------------------------------
    const adminMap = {};
    bookings.forEach((b) => {
      if (b.admin) {
        adminMap[b.admin.id] = {
          id: b.admin.id,
          firstName: b.admin.firstName,
          lastName: b.admin.lastName,
          email: b.admin.email,
          role: b.admin.role,
        };
      }
    });
    const allAdmins = Object.values(adminMap);
    // -------------------------------
    // Previous YEAR Stats
    // -------------------------------
    const calcChange = (current, previousAvg) => {
      if (!previousAvg) return 0;
      return Math.round((current - previousAvg) * 100) / 100;
    };

    const prevYearStart = new Date(now.getFullYear() - 1, 0, 1);
    const prevYearEnd = new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59);

    const prevBookings = await Booking.findAll({
      where: {
        ...whereBooking,
        serviceType: "weekly class membership",
        createdAt: {
          [Op.between]: [prevYearStart, prevYearEnd],
        },
      },
      include: [
        { model: BookingStudentMeta, as: "students", required: true },
        { model: PaymentPlan, as: "paymentPlan", required: false },
      ],
    });

    // -------------------------------
    // Stats Calculation
    // -------------------------------
    const totalSales = memberShipSales.length;

    const totalRevenue = memberShipSales.reduce((acc, b) => {
      const plan = b.paymentPlanData;
      if (plan && plan.price != null) {
        const studentsCount = b.students?.length || 1;
        return acc + (plan.price + (plan.joiningFee || 0)) * studentsCount;
      }
      return acc;
    }, 0);

    const avgMonthlyFeeRaw =
      memberShipSales.reduce((acc, b) => {
        const plan = b.paymentPlanData;
        if (plan && plan.duration && plan.price != null) {
          const studentsCount = b.students?.length || 1;
          const monthlyFee =
            (plan.price + (plan.joiningFee || 0)) / plan.duration;
          return acc + monthlyFee * studentsCount;
        }
        return acc;
      }, 0) / (totalSales || 1);

    // ✅ Round to 2 decimals
    const avgMonthlyFee = Math.round(avgMonthlyFeeRaw * 100) / 100;

    const topSaleAgent = memberShipSales.length > 0 ? 1 : 0; // placeholder
    const prevTotalSales = prevBookings.length;

    const prevTotalRevenue = prevBookings.reduce((acc, b) => {
      const plan = b.paymentPlan;
      if (plan && plan.price != null) {
        const studentsCount = b.students?.length || 1;
        return acc + (plan.price + (plan.joiningFee || 0)) * studentsCount;
      }
      return acc;
    }, 0);

    // 👇 YEARLY AVERAGE (not total)
    const prevRevenueAvg =
      prevTotalSales > 0
        ? Math.round((prevTotalRevenue / prevTotalSales) * 100) / 100
        : 0;

    const prevAvgMonthlyFeeRaw =
      prevBookings.reduce((acc, b) => {
        const plan = b.paymentPlan;
        if (plan && plan.duration && plan.price != null) {
          const studentsCount = b.students?.length || 1;
          return (
            acc +
            ((plan.price + (plan.joiningFee || 0)) / plan.duration) *
            studentsCount
          );
        }
        return acc;
      }, 0) / (prevTotalSales || 1);

    const prevAvgMonthlyFee = Math.round(prevAvgMonthlyFeeRaw * 100) / 100;

    const stats = {
      totalSales: {
        value: totalSales,
        change: calcChange(totalSales, prevTotalSales),
      },
      totalRevenue: {
        value: totalRevenue,
        change: calcChange(totalRevenue, prevTotalRevenue),
      },
      avgMonthlyFee: {
        value: avgMonthlyFee,
        change: calcChange(avgMonthlyFee, prevAvgMonthlyFee),
      },
      topSaleAgent: {
        value: topSaleAgent,
        change: totalSales,
      },
    };

    // -------------------------------
    // Final response
    // -------------------------------
    return {
      status: true,
      message: "Paid bookings retrieved successfully",
      data: {
        memberShipSales,
        venue: allVenues, // ✅ all unique venues
        bookedByAdmins: allAdmins, // ✅ all unique bookedByAdmins
      },
      stats,
    };
  } catch (error) {
    console.error("❌ getActiveMembershipBookings Error:", error.message);
    return { status: false, message: error.message };
  }
};

exports.sendActiveMemberSaleEmailToParents = async ({ bookingId }) => {
  try {
    // 1️⃣ Fetch main booking
    const booking = await Booking.findByPk(bookingId);
    if (!booking) {
      return { status: false, message: "Booking not found" };
    }

    // 2️⃣ Get all students for this booking
    const studentMetas = await BookingStudentMeta.findAll({
      where: { bookingTrialId: bookingId },
    });

    if (!studentMetas.length) {
      return { status: false, message: "No students found for this booking" };
    }

    // 3️⃣ Venue & Class info
    const venue = await Venue.findByPk(booking.venueId);
    const classSchedule = await ClassSchedule.findByPk(booking.classScheduleId);

    const venueName = venue?.venueName || venue?.name || "Unknown Venue";
    const className = classSchedule?.className || "Unknown Class";
    const classTime =
      classSchedule?.classTime || classSchedule?.startTime || "TBA";
    const startDate = booking.startDate;
    const additionalNote = booking.additionalNote || "";

    // 4️⃣ Email template
    const emailConfigResult = await getEmailConfig(
      "admin",
      "send-email-membership",
    );
    if (!emailConfigResult.status) {
      return { status: false, message: "Email config missing" };
    }

    const { emailConfig, htmlTemplate, subject } = emailConfigResult;
    let sentTo = [];

    // 5️⃣ Build students block (all in one list)
    let studentsHtml = "<ul>";
    for (const s of studentMetas) {
      studentsHtml += `<li>${s.studentFirstName} ${s.studentLastName} (Age: ${s.age}, Gender: ${s.gender})</li>`;
    }
    studentsHtml += "</ul>";

    // 6️⃣ Get unique parents across all students
    const allParents = await BookingParentMeta.findAll({
      where: { studentId: studentMetas.map((s) => s.id) },
    });

    const parentsMap = {};
    for (const parent of allParents) {
      if (parent?.parentEmail) {
        parentsMap[parent.parentEmail] = parent;
      }
    }

    // 7️⃣ Send one email per parent with all students listed
    for (const parentEmail in parentsMap) {
      const parent = parentsMap[parentEmail];

      let noteHtml = "";
      if (additionalNote && additionalNote.trim() !== "") {
        noteHtml = `<p><strong>Additional Note:</strong> ${additionalNote}</p>`;
      }

      let finalHtml = htmlTemplate
        .replace(/{{parentName}}/g, parent.parentFirstName)
        .replace(/{{studentsList}}/g, studentsHtml)
        .replace(/{{status}}/g, booking.status)
        .replace(/{{venueName}}/g, venueName)
        .replace(/{{className}}/g, className)
        .replace(/{{classTime}}/g, classTime)
        .replace(/{{startDate}}/g, startDate)
        .replace(/{{additionalNoteSection}}/g, noteHtml)
        .replace(/{{appName}}/g, "Synco")
        .replace(
          /{{logoUrl}}/g,
          "https://webstepdev.com/demo/syncoUploads/syncoLogo.png",
        )
        .replace(
          /{{kidsPlaying}}/g,
          "https://webstepdev.com/demo/syncoUploads/kidsPlaying.png",
        )
        .replace(/{{year}}/g, new Date().getFullYear());

      const recipient = [
        {
          name: `${parent.parentFirstName} ${parent.parentLastName}`,
          email: parent.parentEmail,
        },
      ];

      const sendResult = await sendEmail(emailConfig, {
        recipient,
        subject,
        htmlBody: finalHtml,
      });

      if (sendResult.status) {
        sentTo.push(parent.parentEmail);
      }
    }

    return {
      status: true,
      message: `Emails sent to ${sentTo.length} parents`,
      sentTo,
    };
  } catch (error) {
    console.error("❌ sendActiveMemberSaleEmailToParents Error:", error);
    return { status: false, message: error.message };
  }
};
exports.transferClass = async (data, options) => {
  const t = await sequelize.transaction();
  try {
    const adminId = options?.adminId || null;

    // 1️⃣ Validate booking
    const booking = await Booking.findByPk(data.bookingId, { transaction: t });
    if (!booking) throw new Error("Booking not found.");

    // 2️⃣ Pre-validate ALL students & classes
    const classCapacityMap = {};

    for (const item of data.transfers) {
      const student = await BookingStudentMeta.findOne({
        where: {
          id: item.studentId,
          bookingTrialId: booking.id,
        },
        transaction: t,
      });
      if (!student) throw new Error(`Student ${item.studentId} not found.`);

      // 🔴 SAME CLASS VALIDATION
      if (student.classScheduleId === item.classScheduleId) {
        throw new Error(
          "This student is already enrolled in the selected class. Please choose a different class.",
        );
      }

      const newClass = await ClassSchedule.findByPk(item.classScheduleId, {
        transaction: t,
      });
      if (!newClass)
        throw new Error(`Class ${item.classScheduleId} not found.`);

      classCapacityMap[item.classScheduleId] =
        (classCapacityMap[item.classScheduleId] || 0) + 1;

      item._student = student;
      item._oldClassScheduleId = student.classScheduleId;
      item._newClass = newClass;
    }

    // 3️⃣ Capacity check (IMPORTANT)
    for (const classId in classCapacityMap) {
      const classData = await ClassSchedule.findByPk(classId, {
        transaction: t,
      });
      if (classData.capacity < classCapacityMap[classId]) {
        throw new Error(
          `Not enough slots in "${classData.className}". Required: ${classCapacityMap[classId]}`,
        );
      }
    }

    // 4️⃣ Perform transfers
    for (const item of data.transfers) {
      await item._student.update(
        {
          classScheduleId: item.classScheduleId,
          updatedAt: new Date(),
        },
        { transaction: t },
      );

      // Increase old class capacity
      if (item._oldClassScheduleId) {
        await ClassSchedule.increment(
          { capacity: 1 },
          { where: { id: item._oldClassScheduleId }, transaction: t },
        );
      }

      // Decrease new class capacity
      await ClassSchedule.decrement(
        { capacity: 1 },
        { where: { id: item.classScheduleId }, transaction: t },
      );

      // Log transfer reason
      await CancelBooking.create(
        {
          bookingId: booking.id,
          studentId: item.studentId,
          bookingType: "membership",
          transferReasonClass: item.transferReasonClass,
          createdBy: adminId,
        },
        { transaction: t },
      );
    }

    await t.commit();

    return {
      status: true,
      message: "Classes transferred successfully.",
      data: {
        bookingId: booking.id,
        transferredStudents: data.transfers.map((t) => ({
          studentId: t.studentId,
          newClassScheduleId: t.classScheduleId,
        })),
      },
    };
  } catch (error) {
    await t.rollback();
    return { status: false, message: error.message };
  }
};

// exports.transferClass = async (data, options) => {
//   const t = await sequelize.transaction();
//   try {
//     const adminId = options?.adminId || null;

//     // 🔹 Step 1: Find Booking
//     const booking = await Booking.findByPk(data.bookingId, { transaction: t });
//     if (!booking) throw new Error("Booking not found.");

//     // 🔹 Step 2: Validate new ClassSchedule
//     const newClassSchedule = await ClassSchedule.findByPk(
//       data.classScheduleId, // ✅ match your payload
//       { transaction: t }
//     );
//     if (!newClassSchedule) throw new Error("New class schedule not found.");

//     // 🔹 Step 3: Validate Venue
//     let newVenueId = data.venueId || newClassSchedule.venueId;
//     if (newVenueId) {
//       const newVenue = await Venue.findByPk(newVenueId, { transaction: t });
//       if (!newVenue) throw new Error("New venue not found.");
//     }

//     // 🔹 Step 4: Update Booking
//     booking.classScheduleId = data.classScheduleId;
//     booking.venueId = newVenueId;
//     booking.updatedAt = new Date();
//     await booking.save({ transaction: t });

//     // 🔹 Step 5: Upsert CancelBooking
//     const existingCancel = await CancelBooking.findOne({
//       where: { bookingId: booking.id, bookingType: "membership" },
//       transaction: t,
//     });

//     if (existingCancel) {
//       await existingCancel.update(
//         {
//           transferReasonClass: data.transferReasonClass,
//           updatedAt: new Date(),
//           createdBy: adminId,
//         },
//         { transaction: t }
//       );
//     } else {
//       await CancelBooking.create(
//         {
//           bookingId: booking.id,
//           bookingType: "membership",
//           transferReasonClass: data.transferReasonClass,
//           createdBy: adminId,
//         },
//         { transaction: t }
//       );
//     }

//     // 🔹 Step 6: Commit
//     await t.commit();

//     return {
//       status: true,
//       message: "Class transferred successfully.",
//       data: {
//         bookingId: booking.id,
//         classScheduleId: booking.classScheduleId,
//         venueId: booking.venueId,
//         transferReasonClass: data.transferReasonClass,
//       },
//     };
//   } catch (error) {
//     await t.rollback();
//     return { status: false, message: error.message };
//   }
// };

// exports.addToWaitingListService = async (data, adminId) => {
//   const t = await sequelize.transaction();
//   try {
//     console.log("🚀 [Service] addToWaitingListService started", {
//       data,
//       adminId,
//     });

//     // 1️⃣ Fetch original booking with relations
//     const originalBooking = await Booking.findByPk(data.bookingId, {
//       include: [
//         {
//           model: BookingStudentMeta,
//           as: "students",
//           include: [
//             { model: BookingParentMeta, as: "parents" },
//             { model: BookingEmergencyMeta, as: "emergencyContacts" },
//           ],
//         },
//         { model: BookingPayment, as: "payments" }, // payments under booking
//       ],
//       transaction: t,
//     });

//     if (!originalBooking) throw new Error("Invalid booking selected.");

//     // ✅ Only clone from paid + active bookings
//     if (
//       !(
//         originalBooking.bookingType === "paid" &&
//         originalBooking.status === "active"
//       )
//     ) {
//       throw new Error(
//         `Booking type=${originalBooking.bookingType}, status=${originalBooking.status}. Cannot add to waiting list.`
//       );
//     }

//     // Validate venue and class schedule
//     const venue = await Venue.findByPk(data.venueId, { transaction: t });
//     if (!venue) throw new Error("Venue is required.");

//     const classSchedule = await ClassSchedule.findByPk(data.classScheduleId, {
//       transaction: t,
//     });
//     if (!classSchedule) throw new Error("Class schedule is required.");

//     // Prevent duplicate waiting list entries
//     const studentIds = originalBooking.students.map((s) => s.id);
//     const existingWaiting = await Booking.findOne({
//       where: { classScheduleId: data.classScheduleId, status: "waiting list" },
//       include: [
//         {
//           model: BookingStudentMeta,
//           as: "students",
//           where: { id: studentIds },
//         },
//       ],
//       transaction: t,
//     });

//     if (existingWaiting)
//       throw new Error(
//         "One or more students already have a waiting list entry for this class."
//       );

//     // 2️⃣ Create new waiting list booking (clone paymentPlanId from originalBooking)
//     const waitingBooking = await Booking.create(
//       {
//         bookingId: generateBookingId(),
//         bookingType: "waiting list",
//         venueId: data.venueId,
//         classScheduleId: data.classScheduleId,
//         paymentPlanId: originalBooking.paymentPlanId || null, // clone value, keep null if original is null
//         startDate: data.startDate || null,
//         additionalNote: data.additionalNote || null,
//         bookedBy: adminId,
//         status: "waiting list",
//         totalStudents: originalBooking.totalStudents || 1,
//         interest: originalBooking.interest || "medium",
//         // keyInformation: originalBooking.keyInformation || null,
//       },
//       { transaction: t }
//     );

//     // 3️⃣ Clone payments (linked to booking)
//     for (const payment of originalBooking.payments || []) {
//       await BookingPayment.create(
//         {
//           bookingId: waitingBooking.id,
//           firstName: payment.firstName,
//           lastName: payment.lastName,
//           email: payment.email,
//           billingAddress: payment.billingAddress,
//           cardHolderName: payment.cardHolderName,
//           cv2: payment.cv2,
//           expiryDate: payment.expiryDate,
//           paymentType: payment.paymentType,
//           pan: payment.pan,
//           paymentStatus: payment.paymentStatus,
//           referenceId: payment.referenceId,
//           currency: payment.currency,
//           merchantRef: payment.merchantRef,
//           description: payment.description,
//           commerceType: payment.commerceType,
//           gatewayResponse: payment.gatewayResponse,
//           transactionMeta: payment.transactionMeta,
//         },
//         { transaction: t }
//       );
//     }

//     // 4️⃣ Clone students + parents + emergency contacts
//     for (const student of originalBooking.students) {
//       const newStudent = await BookingStudentMeta.create(
//         {
//           bookingTrialId: waitingBooking.id,
//           studentFirstName: student.studentFirstName,
//           studentLastName: student.studentLastName,
//           dateOfBirth: student.dateOfBirth,
//           age: student.age,
//           gender: student.gender,
//           medicalInformation: student.medicalInformation,
//         },
//         { transaction: t }
//       );

//       for (const parent of student.parents || []) {
//         await BookingParentMeta.create(
//           {
//             studentId: newStudent.id,
//             parentFirstName: parent.parentFirstName,
//             parentLastName: parent.parentLastName,
//             parentEmail: parent.parentEmail,
//             parentPhoneNumber: parent.parentPhoneNumber,
//             relationToChild: parent.relationToChild,
//             howDidYouHear: parent.howDidYouHear,
//           },
//           { transaction: t }
//         );
//       }

//       for (const emergency of student.emergencyContacts || []) {
//         await BookingEmergencyMeta.create(
//           {
//             studentId: newStudent.id,
//             emergencyFirstName: emergency.emergencyFirstName,
//             emergencyLastName: emergency.emergencyLastName,
//             emergencyPhoneNumber: emergency.emergencyPhoneNumber,
//             emergencyRelation: emergency.emergencyRelation,
//           },
//           { transaction: t }
//         );
//       }
//     }

//     // 5️⃣ Reload new booking with relations before commit
//     const finalBooking = await Booking.findByPk(waitingBooking.id, {
//       include: [
//         {
//           model: BookingStudentMeta,
//           as: "students",
//           include: [
//             { model: BookingParentMeta, as: "parents" },
//             { model: BookingEmergencyMeta, as: "emergencyContacts" },
//           ],
//         },
//         { model: BookingPayment, as: "payments" },
//       ],
//       transaction: t,
//     });

//     // 6️⃣ Commit transaction
//     await t.commit();

//     // 7️⃣ Simplified response
//     const simplified = {
//       venueId: finalBooking.venueId,
//       classScheduleId: finalBooking.classScheduleId,
//       paymentPlanId: finalBooking.paymentPlanId,
//       startDate: finalBooking.startDate,
//       totalStudents: finalBooking.totalStudents,
//       // keyInformation: finalBooking.keyInformation,
//       students: finalBooking.students.map((s) => ({
//         studentFirstName: s.studentFirstName,
//         studentLastName: s.studentLastName,
//         dateOfBirth: s.dateOfBirth,
//         age: s.age,
//         gender: s.gender,
//         medicalInformation: s.medicalInformation,
//       })),
//       parents: finalBooking.students.flatMap((s) =>
//         (s.parents || []).map((p) => ({
//           parentFirstName: p.parentFirstName,
//           parentLastName: p.parentLastName,
//           parentEmail: p.parentEmail,
//           parentPhoneNumber: p.parentPhoneNumber,
//           relationToChild: p.relationToChild,
//           howDidYouHear: p.howDidYouHear,
//         }))
//       ),
//       emergency:
//         finalBooking.students
//           .flatMap((s) => s.emergencyContacts || [])
//           .map((e) => ({
//             emergencyFirstName: e.emergencyFirstName,
//             emergencyLastName: e.emergencyLastName,
//             emergencyPhoneNumber: e.emergencyPhoneNumber,
//             emergencyRelation: e.emergencyRelation,
//           }))[0] || null,
//     };

//     return {
//       status: true,
//       message: "Booking added to waiting list successfully.",
//       data: simplified,
//     };
//   } catch (error) {
//     await t.rollback();
//     console.error("❌ [Service] addToWaitingListService error:", error);
//     return {
//       status: false,
//       message: error.message || "Server error.",
//       data: null,
//     };
//   }
// };
// exports.addToWaitingListService = async (data, adminId) => {
//   const t = await sequelize.transaction();
//   try {
//     console.log("🚀 [Service] addToWaitingListService (update existing)", {
//       data,
//       adminId,
//     });

//     // 1️⃣ Fetch the existing booking
//     const booking = await Booking.findByPk(data.bookingId, {
//       include: [
//         { model: BookingStudentMeta, as: "students" },
//         { model: BookingPayment, as: "payments" },
//       ],
//       transaction: t,
//     });

//     if (!booking) throw new Error("Invalid booking selected.");

//     // 2️⃣ Handle "request to cancel" case
//     if (booking.status === "request_to_cancel" || booking.status === "cancelled") {
//       // 🔹 Remove entry from cancel booking table
//       const existingCancel = await CancelBooking.findOne({
//         where: { bookingId: booking.id },
//         transaction: t,
//       });

//       if (existingCancel) {
//         await CancelBooking.destroy({
//           where: { bookingId: booking.id },
//           transaction: t,
//         });
//         console.log("🧹 Removed cancel booking entry for:", booking.id);
//       }

//       // ✅ Update booking to waiting list
//       await booking.update(
//         {
//           status: "waiting list",
//           serviceType: data.serviceType || "weekly class trial",
//           venueId: data.venueId,
//           classScheduleId: data.classScheduleId,
//           startDate: null, // ⬅️ Force reset startDate
//           additionalNote: data.additionalNote || booking.additionalNote,
//           paymentPlanId: data.paymentPlanId,
//           bookedBy: adminId,
//         },
//         { transaction: t }
//       );

//       await t.commit();
//       const updatedBooking = await Booking.findByPk(booking.id, {
//         include: [
//           {
//             model: BookingStudentMeta,
//             as: "students",
//             include: [
//               { model: BookingParentMeta, as: "parents" },
//               { model: BookingEmergencyMeta, as: "emergencyContacts" },
//             ],
//           },
//         ],
//       });

//       return {
//         status: true,
//         message: "Booking moved from cancellation to waiting list successfully.",
//         data: updatedBooking,
//       };
//     }

//     // 3️⃣ For normal cases (active/paid bookings)
//     if (!(booking.bookingType === "paid" && booking.status === "active")) {
//       throw new Error(
//         `Booking type=${booking.bookingType}, status=${booking.status}. Cannot move to waiting list.`
//       );
//     }

//     // 4️⃣ Validate venue and class schedule (optional)
//     const venue = await Venue.findByPk(data.venueId, { transaction: t });
//     if (!venue) throw new Error("Venue is required.");

//     const classSchedule = await ClassSchedule.findByPk(data.classScheduleId, {
//       transaction: t,
//     });
//     if (!classSchedule) throw new Error("Class schedule is required.");

//     // 5️⃣ Delete existing payments
//     // if (booking.payments?.length) {
//     //   const paymentIds = booking.payments.map((p) => p.id);
//     //   await BookingPayment.destroy({
//     //     where: { id: paymentIds },
//     //     transaction: t,
//     //   });
//     // }

//     // 6️⃣ Update booking to waiting list
//     await booking.update(
//       {
//         bookingType: "waiting list",
//         status: "waiting list",
//         serviceType: data.serviceType || "weekly class trial",
//         venueId: data.venueId,
//         classScheduleId: data.classScheduleId,
//         paymentPlanId: data.paymentPlanId,
//         startDate: data.startDate || booking.startDate,
//         additionalNote: data.additionalNote || booking.additionalNote,
//         // paymentPlanId: null,
//         // updatedBy: adminId,
//       },
//       { transaction: t }
//     );

//     await t.commit();

//     // 7️⃣ Fetch updated booking
//     const updatedBooking = await Booking.findByPk(booking.id, {
//       include: [
//         {
//           model: BookingStudentMeta,
//           as: "students",
//           include: [
//             { model: BookingParentMeta, as: "parents" },
//             { model: BookingEmergencyMeta, as: "emergencyContacts" },
//           ],
//         },
//       ],
//     });

//     return {
//       status: true,
//       message: "Booking moved to waiting list successfully.",
//       data: updatedBooking,
//     };
//   } catch (error) {
//     await t.rollback();
//     console.error("❌ [Service] addToWaitingListService error:", error);
//     return {
//       status: false,
//       message: error.message || "Server error.",
//       data: null,
//     };
//   }
// };

// exports.addToWaitingListService = async (data, adminId) => {
//   const t = await sequelize.transaction();
//   try {
//     console.log("🚀 [Service] addToWaitingListService (simplified)", {
//       data,
//       adminId,
//     });

//     // 1️⃣ Fetch existing booking
//     const booking = await Booking.findByPk(data.bookingId, {
//       include: [
//         { model: BookingStudentMeta, as: "students" },
//         { model: BookingPayment, as: "payments" },
//       ],
//       transaction: t,
//     });

//     if (!booking) throw new Error("Invalid booking selected.");

//     // 2️⃣ Validate normal case (only allow active/paid bookings)
//     if (!(booking.bookingType === "paid" && booking.status === "active")) {
//       throw new Error(
//         `Booking type=${booking.bookingType}, status=${booking.status}. Cannot move to waiting list.`
//       );
//     }

//     // 3️⃣ Validate class schedule if provided
//     if (data.classScheduleId) {
//       const classSchedule = await ClassSchedule.findByPk(data.classScheduleId, {
//         transaction: t,
//       });
//       if (!classSchedule) throw new Error("Class schedule is required.");
//     }

//     // 4️⃣ Only update required fields
//     const updateFields = {
//       status: "waiting list",
//       serviceType: "weekly class trial",
//       classScheduleId: data.classScheduleId || booking.classScheduleId,
//       additionalNote: data.additionalNote || booking.additionalNote,
//     };

//     // 5️⃣ Conditionally update startDate
//     if (data.preferedStartDate) {
//       updateFields.startDate = data.preferedStartDate;
//     } else if (data.startDate) {
//       updateFields.startDate = data.startDate;
//     }
//     // else do not touch booking.startDate

//     await booking.update(updateFields, { transaction: t });

//     await t.commit();

//     // 6️⃣ Fetch updated booking for return
//     const updatedBooking = await Booking.findByPk(booking.id, {
//       include: [
//         {
//           model: BookingStudentMeta,
//           as: "students",
//           include: [
//             { model: BookingParentMeta, as: "parents" },
//             { model: BookingEmergencyMeta, as: "emergencyContacts" },
//           ],
//         },
//       ],
//     });

//     return {
//       status: true,
//       message: "Booking updated to waiting list successfully.",
//       data: updatedBooking,
//     };
//   } catch (error) {
//     await t.rollback();
//     console.error("❌ [Service] addToWaitingListService error:", error);
//     return {
//       status: false,
//       message: error.message || "Server error.",
//       data: null,
//     };
//   }
// };

exports.addToWaitingListService = async (data, adminId) => {
  const t = await sequelize.transaction();
  try {
    // 1️⃣ Fetch booking
    const booking = await Booking.findByPk(data.bookingId, {
      include: [{ model: BookingStudentMeta, as: "students" }],
      transaction: t,
    });

    if (!booking) throw new Error("Invalid booking selected.");

    const allowedStatuses = [
      "active",
      "cancelled",
      "request_to_cancel",
      "frozen",
    ];

    if (
      booking.bookingType !== "paid" ||
      !allowedStatuses.includes(booking.status)
    ) {
      throw new Error("Booking cannot be moved to waiting list.");
    }

    // 2️⃣ Validate students payload
    if (!Array.isArray(data.students) || !data.students.length) {
      throw new Error("At least one student is required.");
    }

    // 3️⃣ Validate EACH student + class
    for (const s of data.students) {
      if (!s.studentId || !s.classScheduleId) {
        throw new Error("studentId and classScheduleId are required.");
      }

      const student = await BookingStudentMeta.findOne({
        where: {
          id: s.studentId,
          bookingTrialId: booking.id,
        },
        transaction: t,
      });

      if (!student) {
        throw new Error(`Student ${s.studentId} not found in booking.`);
      }

      const classSchedule = await ClassSchedule.findByPk(s.classScheduleId, {
        transaction: t,
      });

      if (!classSchedule) {
        throw new Error(`Class schedule ${s.classScheduleId} not found.`);
      }
    }

    // 4️⃣ Update students (student-wise class)
    for (const s of data.students) {
      await BookingStudentMeta.update(
        {
          classScheduleId: s.classScheduleId,
          additionalNote: data.additionalNote,
          preferredStartDate: data.preferedStartDate || data.startDate,
        },
        {
          where: {
            id: s.studentId,
            bookingTrialId: booking.id,
          },
          transaction: t,
        },
      );
    }

    // 5️⃣ Update booking status ONLY
    await booking.update({ status: "waiting list" }, { transaction: t });

    await t.commit();

    // 6️⃣ Return updated booking
    const updatedBooking = await Booking.findByPk(booking.id, {
      include: [
        {
          model: BookingStudentMeta,
          as: "students",
          include: [
            { model: BookingParentMeta, as: "parents" },
            { model: BookingEmergencyMeta, as: "emergencyContacts" },
          ],
        },
      ],
    });

    return {
      status: true,
      message: "Students added to waiting list successfully.",
      data: updatedBooking,
    };
  } catch (error) {
    await t.rollback();
    return {
      status: false,
      message: error.message,
      data: null,
    };
  }
};

exports.getWaitingList = async () => {
  try {
    const waitingListEntries = await WaitingList.findAll({
      include: [
        {
          model: Booking,
          as: "booking",
          include: [
            {
              model: BookingStudentMeta,
              as: "students",
              include: [
                { model: BookingParentMeta, as: "parents" },
                { model: BookingEmergencyMeta, as: "emergencyContacts" },
              ],
            },
          ],
        },
        { model: Venue, as: "venue" },
        { model: ClassSchedule, as: "classSchedule" },
      ],
      order: [["createdAt", "DESC"]],
    });

    const formattedData = waitingListEntries.map((entry) => {
      const booking = entry.booking;

      const students = booking.students.map((student) => ({
        studentFirstName: student.studentFirstName,
        studentLastName: student.studentLastName,
        dateOfBirth: student.dateOfBirth,
        age: student.age,
        gender: student.gender,
        medicalInformation: student.medicalInformation,
      }));

      const parents = booking.students.flatMap((student) =>
        student.parents.map((p) => ({
          parentFirstName: p.parentFirstName,
          parentLastName: p.parentLastName,
          parentEmail: p.parentEmail,
          parentPhoneNumber: p.parentPhoneNumber,
          relationToChild: p.relationToChild,
          howDidYouHear: p.howDidYouHear,
        })),
      );

      const emergencyContactRaw =
        booking.students[0]?.emergencyContacts?.[0] || null;

      const emergency = emergencyContactRaw
        ? {
          emergencyFirstName: emergencyContactRaw.emergencyFirstName,
          emergencyLastName: emergencyContactRaw.emergencyLastName,
          emergencyPhoneNumber: emergencyContactRaw.emergencyPhoneNumber,
          emergencyRelation: emergencyContactRaw.emergencyRelation,
        }
        : null;

      return {
        id: entry.id,
        bookingId: booking.id, // <-- bookingId included
        venue: entry.venue,
        classSchedule: entry.classSchedule,

        students,
        parents,
        emergency,
      };
    });

    return {
      status: true,
      data: formattedData,
      message: "Waiting list retrieved successfully",
    };
  } catch (error) {
    console.error("❌ getWaitingList service error:", error);
    return { status: false, message: error.message };
  }
};

exports.getBookingsById = async (bookingId) => {
  try {
    const booking = await Booking.findOne({
      where: {
        id: bookingId,
        bookingType: { [Op.or]: ["waiting list", "paid", "removed"] }, // <-- both types
        // serviceType: "weekly class membership",
        serviceType: {
          [Op.in]: ["weekly class membership", "weekly class trial"], // ✅ both types
        },
      },
      include: [
        {
          model: BookingStudentMeta,
          as: "students",
          include: [
            {
              model: ClassSchedule,
              as: "classSchedule",
              required: false,
              include: [{ model: Venue, as: "venue", required: false }],
            },
            { model: BookingParentMeta, as: "parents", required: false },
            {
              model: BookingEmergencyMeta,
              as: "emergencyContacts",
              required: false,
            },
          ],
          required: false,
        },
        { model: BookingPayment, as: "payments", required: false },
        { model: PaymentPlan, as: "paymentPlan", required: false },
        {
          model: Admin,
          as: "bookedByAdmin",
          attributes: [
            "id",
            "firstName",
            "lastName",
            "email",
            "roleId",
            "status",
            "profile",
          ],
          required: false,
        },
        {
          model: FreezeBooking,
          as: "freezeBooking",
          required: false,
        },
      ],
    });

    if (!booking) {
      return { status: false, message: "Booking not found" };
    }

    // ✅ collect venueIds from student class schedules
    const venueIds = new Set();

    for (const student of booking.students || []) {
      if (student.classScheduleId) {
        const classSchedule = await ClassSchedule.findByPk(
          student.classScheduleId,
          { attributes: ["venueId"] },
        );

        if (classSchedule?.venueId) {
          venueIds.add(classSchedule.venueId);
        }
      }
    }

    // 🔎 fetch all class schedules from those venues
    let newClasses = [];

    if (venueIds.size > 0) {
      newClasses = await ClassSchedule.findAll({
        where: {
          venueId: [...venueIds],
        },
      });
    }
    let noCapacityClass = [];

    if (venueIds) {
      // 🔹 jisme capacity na ho
      noCapacityClass = newClasses.filter((cls) => cls.capacity <= 0);
    }
    // ✅ Parse booking as before
    const students =
      booking.students?.map((s) => ({
        id: s.id, // <-- DB id
        studentFirstName: s.studentFirstName,
        studentLastName: s.studentLastName,
        dateOfBirth: s.dateOfBirth,
        age: s.age,
        gender: s.gender,
        medicalInformation: s.medicalInformation,
        classScheduleId: s.classScheduleId,
        // ✅ student-wise class schedule
        classSchedule: s.classSchedule
          ? {
            id: s.classSchedule.id,
            className: s.classSchedule.className,
            startTime: s.classSchedule.startTime,
            endTime: s.classSchedule.endTime,
          }
          : null,
      })) || [];

    const parents =
      booking.students?.flatMap(
        (s) =>
          s.parents?.map((p) => ({
            id: p.id, // <-- DB id
            parentFirstName: p.parentFirstName,
            parentLastName: p.parentLastName,
            parentEmail: p.parentEmail,
            parentPhoneNumber: p.parentPhoneNumber,
            relationToChild: p.relationToChild,
            howDidYouHear: p.howDidYouHear,
          })) || [],
      ) || [];

    const emergency =
      booking.students?.flatMap(
        (s) =>
          s.emergencyContacts?.map((e) => ({
            id: e.id, // <-- DB id
            emergencyFirstName: e.emergencyFirstName,
            emergencyLastName: e.emergencyLastName,
            emergencyPhoneNumber: e.emergencyPhoneNumber,
            emergencyRelation: e.emergencyRelation,
          })) || [],
      ) || [];

    // const venue = booking.classSchedule?.venue || null;
    const venue = booking.students?.[0]?.classSchedule?.venue || null;
    const plan = booking.paymentPlan || null;

    const payments =
      booking.payments?.map((p) => ({
        ...p.get({ plain: true }),
        gatewayResponse: (() => {
          try {
            return JSON.parse(p.gatewayResponse);
          } catch {
            return p.gatewayResponse;
          }
        })(),
        transactionMeta: (() => {
          try {
            return JSON.parse(p.transactionMeta);
          } catch {
            return p.transactionMeta;
          }
        })(),
        goCardlessBankAccount: (() => {
          try {
            return JSON.parse(p.goCardlessBankAccount);
          } catch {
            return p.goCardlessBankAccount;
          }
        })(),
      })) || [];

    const payment = payments[0] || null;

    const parsedBooking = {
      bookingId: booking.id,
      bookedId: booking.bookingId,
      freezeBooking: booking.freezeBooking,
      serviceType: booking.serviceType,
      status: booking.status,
      startDate: booking.startDate,
      dateBooked: booking.createdAt,

      students,
      parents,
      emergency,

      classSchedule: booking.classSchedule || null,
      venue,
      paymentPlan: plan,
      payments,

      paymentData: payment
        ? {
          firstName: payment.firstName,
          lastName: payment.lastName,
          email: payment.email,
          billingAddress: payment.billingAddress,
          paymentStatus: payment.paymentStatus,
          totalCost: plan ? plan.price + (plan.joiningFee || 0) : 0,
        }
        : null,

      bookedByAdmin: booking.bookedByAdmin || null,
      newClasses,
      noCapacityClass,
    };

    return {
      status: true,
      message: "Paid booking retrieved successfully",
      totalPaidBookings: 1,
      data: parsedBooking,
    };
  } catch (error) {
    console.error("❌ getBookingsById Error:", error.message);
    return { status: false, message: error.message };
  }
};

exports.retryBookingPayment = async (bookingId, newData) => {
  console.log(
    "🔹 [Service] Starting retryBookingPayment for bookingId:",
    bookingId,
  );

  const t = await sequelize.transaction();
  try {
    // Step 1: Find Booking
    const booking = await Booking.findByPk(bookingId, { transaction: t });
    if (!booking) throw new Error("Booking not found");
    console.log("✅ [Service] Booking found:", booking.id);

    // Step 2: Find latest payment
    const latestPayment = await BookingPayment.findOne({
      where: { bookingId: booking.id },
      order: [["createdAt", "DESC"]],
      transaction: t,
    });
    if (!latestPayment) throw new Error("No payment found to retry");

    if (latestPayment.paymentStatus === "paid") {
      console.log("⚠️ Payment already successful, nothing to retry.");
      await t.commit();
      return {
        status: true,
        message: "Payment already successful, nothing to retry.",
        paymentStatus: "paid",
        studentId: booking.studentId,
      };
    }

    // Step 3: Load plan
    if (newData.paymentPlanId) {
      booking.paymentPlanId = newData.paymentPlanId;
      await booking.save({ transaction: t });
      console.log("✅ Booking plan updated");
    }

    const paymentPlan = await PaymentPlan.findByPk(booking.paymentPlanId, {
      transaction: t,
    });
    if (!paymentPlan) throw new Error("Invalid payment plan selected.");
    const price = paymentPlan.price || 0;

    const venue = await Venue.findByPk(booking.venueId, { transaction: t });
    const classSchedule = await ClassSchedule.findByPk(
      booking.classScheduleId,
      { transaction: t },
    );

    const merchantRef = `TXN-${Math.floor(1000 + Math.random() * 9000)}`;

    let paymentStatusFromGateway = "pending";
    let gatewayResponse = null;
    let transactionMeta = null;

    // Step 4: Retry payment
    // Step 4: Retry payment
    try {
      if (newData?.payment?.paymentType === "bank") {
        console.log("🔹 [Service] Retrying via GoCardless bank...");

        if (!newData.payment.referenceId)
          throw new Error("Reference ID is required for bank payments.");

        const gcPayload = {
          billing_requests: {
            payment_request: {
              amount: Math.round(price * 100), // in pence
              currency: "GBP",
              description: `Booking retry for ${venue?.name || "Venue"} - ${classSchedule?.className || "Class"
                }`,
              metadata: {
                bookingId: String(booking.id), // must be string
                retry: "true", // must be string
                referenceId: newData.payment.referenceId,
              },
            },
            mandate_request: {
              currency: "GBP",
              scheme: "bacs",
              metadata: {
                bookingId: String(booking.id), // must be string
              },
            },
            metadata: { test: `BR${Math.floor(Math.random() * 1000000)}` },
            links: {},
          },
        };

        console.log("📦 bank Payload:", gcPayload);

        // ✅ Fetch GoCardless access token from AppConfig
        const gcAccessTokenConfig = await AppConfig.findOne({
          where: { key: "GC_HEAD_OFFICE_TOKEN" },
          transaction: t,
        });

        if (!gcAccessTokenConfig || !gcAccessTokenConfig.value) {
          throw new Error("Missing GC_HEAD_OFFICE_TOKEN in AppConfig table.");
        }

        const GC_HEAD_OFFICE_TOKEN = gcAccessTokenConfig.value;

        // ✅ Make GoCardless API call
        const response = await axios.post(
          "https://api-sandbox.gocardless.com/billing_requests",
          gcPayload,
          {
            headers: {
              Authorization: `Bearer ${GC_HEAD_OFFICE_TOKEN}`, // ✅ from DB, not env
              "Content-Type": "application/json",
              "GoCardless-Version": "2015-07-06",
            },
          },
        );

        gatewayResponse = response.data;
        console.log("✅ GoCardless Response:", gatewayResponse);

        const status =
          response.data?.billing_requests?.status?.toLowerCase() || "failed";

        transactionMeta = { status };

        if (["submitted", "pending_submission", "pending"].includes(status))
          paymentStatusFromGateway = "pending";
        else if (status === "confirmed" || status === "paid")
          paymentStatusFromGateway = "paid";
        else if (["failed", "cancelled"].includes(status))
          paymentStatusFromGateway = "failed";
        else paymentStatusFromGateway = "unknown";

        // Force failed if not paid or pending
        if (
          paymentStatusFromGateway !== "paid" &&
          paymentStatusFromGateway !== "pending"
        ) {
          paymentStatusFromGateway = "failed";
        }

        console.log(
          "🔹 [Service] Payment status mapped:",
          paymentStatusFromGateway,
        );
      } else if (newData?.payment?.paymentType === "card") {
        console.log("🔹 [Service] Retrying via Pay360 card...");
        const { pan, expiryDate, cardHolderName, cv2 } = newData.payment || {};
        if (!pan || !expiryDate || !cardHolderName || !cv2)
          throw new Error("Missing required card details for Pay360 payment.");

        const paymentPayload = {
          transaction: {
            currency: "GBP",
            amount: price,
            merchantRef,
            description: `${venue?.name || "Venue"} - ${classSchedule?.className || "Class"
              }`,
            commerceType: "ECOM",
          },
          paymentMethod: { card: { pan, expiryDate, cardHolderName, cv2 } },
        };

        console.log("📦 Pay360 Payload:", paymentPayload);

        // ✅ Fetch Pay360 credentials from AppConfig
        const [instIdConfig, usernameConfig, passwordConfig] =
          await Promise.all([
            AppConfig.findOne({
              where: { key: "PAY360_INST_ID" },
              transaction: t,
            }),
            AppConfig.findOne({
              where: { key: "PAY360_API_USERNAME" },
              transaction: t,
            }),
            AppConfig.findOne({
              where: { key: "PAY360_API_PASSWORD" },
              transaction: t,
            }),
          ]);

        if (!instIdConfig || !usernameConfig || !passwordConfig) {
          throw new Error("Missing Pay360 configuration in AppConfig table.");
        }

        const PAY360_INST_ID = instIdConfig.value;
        const PAY360_API_USERNAME = usernameConfig.value;
        const PAY360_API_PASSWORD = passwordConfig.value;

        // ✅ Construct Pay360 API URL dynamically
        const url = `https://api.mite.pay360.com/acceptor/rest/transactions/${PAY360_INST_ID}/payment`;

        // ✅ Encode Basic Auth Header
        const authHeader = Buffer.from(
          `${PAY360_API_USERNAME}:${PAY360_API_PASSWORD}`,
        ).toString("base64");

        const response = await axios.post(url, paymentPayload, {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Basic ${authHeader}`,
          },
        });

        gatewayResponse = response.data;
        console.log("✅ Pay360 Response:", gatewayResponse);

        const status =
          response.data?.transaction?.status?.toLowerCase() || "failed";

        transactionMeta = { status };

        if (status === "success" || status === "already_paid")
          paymentStatusFromGateway = "paid";
        else if (status === "pending") paymentStatusFromGateway = "pending";
        else paymentStatusFromGateway = "failed";

        // Force failed if not paid or pending
        if (
          paymentStatusFromGateway !== "paid" &&
          paymentStatusFromGateway !== "pending"
        ) {
          paymentStatusFromGateway = "failed";
        }
      } else {
        throw new Error("Unsupported or missing payment type for retry.");
      }
    } catch (err) {
      console.error(
        "❌ Payment gateway error:",
        err.response?.data || err.message,
      );
      paymentStatusFromGateway = "failed";
      gatewayResponse = err.response?.data || { error: err.message };
      transactionMeta = { status: "failed" };
    }

    // Step 5: Update existing BookingPayment
    console.log("🔹 [Service] Updating BookingPayment retry entry...");

    const existingPayment = await BookingPayment.findOne({
      where: { bookingId: booking.id },
      order: [["createdAt", "DESC"]],
      transaction: t,
    });

    if (!existingPayment) throw new Error("No payment record found to update.");

    const firstStudent = await BookingStudentMeta.findOne({
      where: { bookingTrialId: booking.id },
      order: [["createdAt", "ASC"]],
      transaction: t,
    });
    const firstParent = newData.parents?.[0] || {};

    await existingPayment.update(
      {
        studentId: firstStudent?.id || null,
        paymentType: newData.payment.paymentType,
        referenceId: newData.payment.referenceId || existingPayment.referenceId,
        paymentStatus: paymentStatusFromGateway,
        amount: price,
        gatewayResponse, // full raw payload
        transactionMeta, // only { status }
        firstName:
          newData.payment.firstName || firstParent.parentFirstName || "Parent",
        lastName: newData.payment.lastName || firstParent.parentLastName || "",
        merchantRef,
        description: `${venue?.name || "Venue"} - ${classSchedule?.className || "Class"
          }`,
        commerceType: "ECOM",
        email: newData.payment.email || firstParent.parentEmail || "",
        billingAddress: newData.payment.billingAddress || "",
        cardHolderName: newData.payment.cardHolderName || "",
        cv2: newData.payment.cv2 || "",
        expiryDate: newData.payment.expiryDate || "",
        pan: newData.payment.pan || "",
        updatedAt: new Date(),
      },
      { transaction: t },
    );

    console.log(
      `✅ [Service] BookingPayment retry updated with status: ${paymentStatusFromGateway}`,
    );

    await t.commit();
    return {
      status: true,
      message: `Retry payment completed with status: ${paymentStatusFromGateway}`,
      paymentStatus: paymentStatusFromGateway,
      studentId: firstStudent?.id || null,
    };
  } catch (error) {
    console.error("❌ Error in retryBookingPayment:", error.message);
    await t.rollback();
    return { status: false, message: error.message };
  }
};

exports.getFailedPaymentsByBookingId = async (bookingId) => {
  if (!bookingId) {
    throw new Error("Booking ID is required");
  }

  const failedPayments = await BookingPayment.findAll({
    where: {
      bookingId,
      paymentStatus: "failed", // Only failed payments
    },
    order: [["createdAt", "DESC"]],
  });

  // Parse gatewayResponse and transactionMeta
  const parsedPayments = failedPayments.map((payment) => {
    let gatewayResponse = payment.gatewayResponse;
    let transactionMeta = payment.transactionMeta;
    let goCardlessCustomer = payment.goCardlessCustomer;
    let goCardlessBankAccount = payment.goCardlessBankAccount;
    let goCardlessBillingRequest = payment.goCardlessBillingRequest;

    // Ensure JSON parsing if stored as string
    if (typeof gatewayResponse === "string") {
      try {
        gatewayResponse = JSON.parse(gatewayResponse);
      } catch (err) {
        console.error("Failed to parse gatewayResponse:", err.message);
      }
    }

    if (typeof transactionMeta === "string") {
      try {
        transactionMeta = JSON.parse(transactionMeta);
      } catch (err) {
        console.error("Failed to parse transactionMeta:", err.message);
      }
    }

    if (typeof goCardlessCustomer === "string") {
      try {
        goCardlessCustomer = JSON.parse(goCardlessCustomer);
      } catch (err) {
        console.error("Failed to parse goCardlessCustomer:", err.message);
      }
    }
    if (typeof goCardlessBankAccount === "string") {
      try {
        goCardlessBankAccount = JSON.parse(goCardlessBankAccount);
      } catch (err) {
        console.error("Failed to parse goCardlessBankAccount:", err.message);
      }
    }
    if (typeof goCardlessBillingRequest === "string") {
      try {
        goCardlessBillingRequest = JSON.parse(goCardlessBillingRequest);
      } catch (err) {
        console.error("Failed to parse goCardlessBillingRequest:", err.message);
      }
    }

    return {
      id: payment.id,
      bookingId: payment.bookingId,
      studentId: payment.studentId,
      paymentType: payment.paymentType,
      // amount: payment.amount,
      paymentStatus: payment.paymentStatus,
      createdAt: payment.createdAt,
      updatedAt: payment.updatedAt,
      gatewayResponse, // parsed object
      transactionMeta, // parsed object
      goCardlessCustomer,
      goCardlessBankAccount,
    };
  });

  return parsedPayments;
};

exports.updateBookingWithStudents = async (
  bookingId,
  studentsPayload,
  transaction,
) => {
  try {
    // 🔹 Fetch booking with associations
    const booking = await Booking.findOne({
      where: { id: bookingId },
      include: [
        {
          model: BookingStudentMeta,
          as: "students",
          include: [
            { model: BookingParentMeta, as: "parents", required: false },
            {
              model: BookingEmergencyMeta,
              as: "emergencyContacts",
              required: false,
            },
          ],
          required: false,
        },
      ],
      transaction,
    });

    if (!booking) {
      return { status: false, message: "Booking not found" };
    }

    // 🔹 Update or create students, parents, emergency contacts
    let adminSynced = false; // 🔐 ensure admin updates once

    for (const student of studentsPayload) {
      let studentRecord;

      // 🔹 Student
      if (student.id) {
        studentRecord = booking.students.find((s) => s.id === student.id);
        if (!studentRecord) continue;

        [
          "studentFirstName",
          "studentLastName",
          "dateOfBirth",
          "age",
          "gender",
          "medicalInformation",
        ].forEach((field) => {
          if (student[field] !== undefined)
            studentRecord[field] = student[field];
        });

        await studentRecord.save({ transaction });
      } else {
        studentRecord = await BookingStudentMeta.create(
          { bookingId, ...student },
          { transaction },
        );
      }

      // 🔹 Parents
      if (Array.isArray(student.parents)) {
        for (let index = 0; index < student.parents.length; index++) {
          const parent = student.parents[index];
          const isFirstParent =
            index === 0 && booking.parentAdminId && !adminSynced;

          // 🔒 PRE-CHECK admin email uniqueness
          if (isFirstParent && parent.parentEmail) {
            const admin = await Admin.findByPk(booking.parentAdminId, {
              transaction,
              paranoid: false,
            });

            if (admin && parent.parentEmail !== admin.email) {
              const emailExists = await Admin.findOne({
                where: {
                  email: parent.parentEmail,
                  id: { [Op.ne]: admin.id },
                },
                transaction,
                paranoid: false,
              });

              if (emailExists) {
                throw new Error("This email is already in use");
              }
            }
          }

          // 🔹 Parent update / create
          let parentRecord;
          if (parent.id) {
            parentRecord = studentRecord.parents?.find(
              (p) => p.id === parent.id,
            );

            if (parentRecord) {
              [
                "parentFirstName",
                "parentLastName",
                "parentEmail",
                "parentPhoneNumber",
                "relationToChild",
                "howDidYouHear",
              ].forEach((field) => {
                if (parent[field] !== undefined)
                  parentRecord[field] = parent[field];
              });

              await parentRecord.save({ transaction });
            }
          } else {
            parentRecord = await BookingParentMeta.create(
              { bookingStudentMetaId: studentRecord.id, ...parent },
              { transaction },
            );
          }

          // 🔹 Sync FIRST parent → Admin (once)
          if (isFirstParent) {
            const admin = await Admin.findByPk(booking.parentAdminId, {
              transaction,
              paranoid: false,
            });

            if (admin) {
              if (parent.parentFirstName !== undefined)
                admin.firstName = parent.parentFirstName;

              if (parent.parentLastName !== undefined)
                admin.lastName = parent.parentLastName;

              if (parent.parentEmail !== undefined)
                admin.email = parent.parentEmail;

              if (parent.parentPhoneNumber !== undefined)
                admin.phoneNumber = parent.parentPhoneNumber;

              await admin.save({ transaction });
              adminSynced = true;
            }
          }
        }
      }

      // 🔹 Emergency contacts
      if (Array.isArray(student.emergencyContacts)) {
        for (const emergency of student.emergencyContacts) {
          if (emergency.id) {
            const emergencyRecord = studentRecord.emergencyContacts?.find(
              (e) => e.id === emergency.id,
            );

            if (emergencyRecord) {
              [
                "emergencyFirstName",
                "emergencyLastName",
                "emergencyPhoneNumber",
                "emergencyRelation",
              ].forEach((field) => {
                if (emergency[field] !== undefined)
                  emergencyRecord[field] = emergency[field];
              });

              await emergencyRecord.save({ transaction });
            }
          } else {
            await BookingEmergencyMeta.create(
              { bookingStudentMetaId: studentRecord.id, ...emergency },
              { transaction },
            );
          }
        }
      }
    }

    // 🔹 Prepare structured response like getBookingsById
    const students =
      booking.students?.map((s) => ({
        studentId: s.id,
        studentFirstName: s.studentFirstName,
        studentLastName: s.studentLastName,
        dateOfBirth: s.dateOfBirth,
        age: s.age,
        gender: s.gender,
        medicalInformation: s.medicalInformation,
      })) || [];

    const parents =
      booking.students?.flatMap(
        (s) =>
          s.parents?.map((p) => ({
            parentId: p.id,
            parentFirstName: p.parentFirstName,
            parentLastName: p.parentLastName,
            parentEmail: p.parentEmail,
            parentPhoneNumber: p.parentPhoneNumber,
            relationToChild: p.relationToChild,
            howDidYouHear: p.howDidYouHear,
          })) || [],
      ) || [];

    const emergencyContacts =
      booking.students?.flatMap(
        (s) =>
          s.emergencyContacts?.map((e) => ({
            emergencyId: e.id,
            emergencyFirstName: e.emergencyFirstName,
            emergencyLastName: e.emergencyLastName,
            emergencyPhoneNumber: e.emergencyPhoneNumber,
            emergencyRelation: e.emergencyRelation,
          })) || [],
      ) || [];

    return {
      status: true,
      message: "Booking updated successfully",
      data: {
        bookingId: booking.id,
        status: booking.status,
        students,
        parents,
        emergencyContacts,
      },
    };
  } catch (error) {
    console.error("❌ Service updateBookingWithStudents Error:", error.message);
    return { status: false, message: error.message };
  }
};
