const { logActivity } = require("../../../../utils/admin/activityLogger");
const {
  createNotification,
} = require("../../../../utils/admin/notificationHelper");
const CancelClassService = require("../../../../services/admin/holidayCamps/classSchedule/holidayCancelSession");
const getHolidayClassByIdWithFullDetails = require("../../../../services/admin/holidayCamps/classSchedule/holidayClassSchedule");
const ClassScheduleService = require("../../../../services/admin/holidayCamps/classSchedule/holidayClassSchedule");

const DEBUG = process.env.DEBUG === "true";
const PANEL = "admin";
const MODULE = "cancel-class";

exports.cancelClassSession = async (req, res) => {
  try {
    const { classScheduleId } = req.params;
    const {
      reasonForCancelling,
      notifyMembers = "No",
      creditMembers = "No",
      notifyTrialists = "No",
      notifyCoaches = "No",
      roles = [],
    } = req.body;

    const adminId = req.admin?.id;

    if (DEBUG) {
      console.log("📥 Cancel request for classScheduleId:", classScheduleId);
      console.log("📥 Roles config:", roles);
    }

    // --- NEW: extract mapId from query ---
    const mapIdRaw = req.query.mapId;
    const mapId = mapIdRaw ? parseInt(mapIdRaw, 10) : null;

    if (DEBUG) {
      console.log("🔍 mapId from query:", mapIdRaw, "parsed:", mapId);
    }

    if (!mapId) {
      await logActivity(
        req,
        PANEL,
        MODULE,
        "cancel",
        { message: "mapId query param required" },
        false
      );
      return res.status(400).json({
        status: false,
        message: "Missing required query parameter: mapId",
      });
    }

    const holidayClassScheduleCampDateMapResult = await ClassScheduleService.getClassScheduleCampDateMapById(mapId);
    console.log(`holidayClassScheduleCampDateMapResult - `, holidayClassScheduleCampDateMapResult);
    if (!holidayClassScheduleCampDateMapResult.status) {
      await logActivity(
        req,
        PANEL,
        MODULE,
        "cancel",
        { message: holidayClassScheduleCampDateMapResult.message },
        false
      );
      return res.status(400).json({
        status: false,
        message: holidayClassScheduleCampDateMapResult.message
      });
    }

    const mapEntry = holidayClassScheduleCampDateMapResult.mapEntry;

    const cancelSessionPlanResult =
      await CancelClassService.getCancelledSessionByMapIdSessionPlanId(
        mapEntry.id,            // ✅ mapId
        mapEntry.sessionPlanId  // ✅ sessionPlanGroupId
      );

    console.log(`cancelSessionPlanResult - `, cancelSessionPlanResult);

    if (cancelSessionPlanResult.status) {
      await logActivity(
        req,
        PANEL,
        MODULE,
        "cancel",
        { message: `Session Plan has already been cancelled.` },
        false
      );
      return res.status(400).json({
        status: false,
        message: `Session Plan has already been cancelled.`
      });
    }

    if (!Array.isArray(roles) || roles.length === 0) {
      await logActivity(
        req,
        PANEL,
        MODULE,
        "cancel",
        { message: "Roles array required" },
        false
      );
      return res.status(400).json({
        status: false,
        message: "Invalid payload: 'roles' must be a non-empty array.",
      });
    }

    const notifications = roles.map((roleConfig) => ({
      role: roleConfig.notifyType,
      subjectLine: roleConfig.subjectLine,
      emailBody: roleConfig.emailBody,
      deliveryMethod: roleConfig.deliveryMethod || "Email",
      templateKey: roleConfig.templateKey || "cancel",
    }));

    const cancelData = {
      reasonForCancelling,
      notifyMembers,
      creditMembers,
      notifyTrialists,
      notifyCoaches,
      notifications,
      mapId,
    };

    const cancelResult = await CancelClassService.createCancellationRecord(
      classScheduleId,
      cancelData,
      adminId
    );

    const hasSuccess = cancelResult.status === true;

    await logActivity(req, PANEL, MODULE, "cancel", cancelResult, hasSuccess);

    if (hasSuccess) {
      // Try to get createdBy safely (admin or from map result)
      const createdBy = req?.admin?.id || holidayClassScheduleCampDateMapResult?.mapEntry?.createdBy;

      // Fetch class details including className
      const classDetails = await ClassScheduleService.getHolidayClassByIdWithFullDetails(classScheduleId, createdBy);
      const className = classDetails?.data?.className || "Unknown Class";

      // Get admin name (first + last, or fallback to "Admin")
      const cancelledBy = req?.admin
        ? `${req.admin.firstName} ${req.admin.lastName}`.trim()
        : "Admin";

      // Create notification with proper details
      await createNotification(
        req,
        "Class Session Cancelled",
        `Class "${className}" was cancelled by ${cancelledBy}.`,
        "Admins"
      );
    }

    let successMessage = "Class session cancelled successfully.";

    if (hasSuccess) {
      if (cancelResult.emailsSent === false) {
        successMessage =
          "Class cancelled successfully. No bookings found, so no notification emails were sent.";
      } else if (cancelResult.emailsSent === true) {
        successMessage =
          "Class cancelled successfully and notification emails have been sent.";
      }
    }

    return res.status(hasSuccess ? 201 : 400).json({
      status: hasSuccess,
      message: successMessage,
      data: cancelResult.data,
    });

  } catch (error) {
    console.error("❌ Error cancelling class session:", error);
    await logActivity(
      req,
      PANEL,
      MODULE,
      "cancel",
      { error: error.message },
      false
    );
    return res.status(500).json({
      status: false,
      message: "An error occurred while cancelling class session.",
      error: error.message,
    });
  }
};

// ✅ Get a single cancelled session by ID
exports.getCancelledSessionById = async (req, res) => {
  if (DEBUG) console.log("📥 Received request to get cancelled session by ID");

  try {
    const { id } = req.params;
    const result = await CancelClassService.getCancelledSessionById(id);

    if (!result.status) {
      if (DEBUG) console.log("⚠️ Service failed:", result.message);
      await logActivity(req, PANEL, MODULE, "view", result, false);
      return res.status(404).json({ status: false, message: result.message });
    }

    await logActivity(
      req,
      PANEL,
      MODULE,
      "view",
      { oneLineMessage: `Fetched cancelled session ID: ${id}` },
      true
    );

    return res.status(200).json({
      status: true,
      message: "Fetched cancelled session successfully.",
      data: result.data,
    });
  } catch (error) {
    console.error("❌ Error fetching cancelled session:", error);
    await logActivity(
      req,
      PANEL,
      MODULE,
      "view",
      { oneLineMessage: error.message },
      false
    );
    return res.status(500).json({ status: false, message: "Server error." });
  }
};