
// function toReadableFieldName(field) {
//   return field
//     .replace(/[-_]/g, " ")
//     .replace(/([a-z])([A-Z])/g, "$1 $2")
//     .replace(/\b\w/g, (char) => char.toUpperCase());
// }

// function isValidEmail(value) {
//   return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
// }

// function isValidURL(value) {
//   try {
//     new URL(value);
//     return true;
//   } catch {
//     return false;
//   }
// }

// function isValidPhone(value) {
//   return /^[\d\s()+-]{7,15}$/.test(value);
// }

// function validateFormData(formData, options = {}) {
//   const requiredFields = options.requiredFields || [];
//   const patternValidations = options.patternValidations || {};
//   const fileExtensionValidations = options.fileExtensionValidations || {};

//   const error = {};

//   // 1. Required field validation
//   for (const field of requiredFields) {
//     const value = formData[field];
//     if (
//       value === undefined ||
//       value === null ||
//       (typeof value === "string" && value.trim() === "")
//     ) {
//       error[field] = `${toReadableFieldName(field)} is required.`;
//     }
//   }

//   // 2. Pattern validations
//   for (const field in patternValidations) {
//     const rule = patternValidations[field];
//     const value = formData[field];

//     if (value !== undefined && value !== null) {
//       const val = typeof value === "string" ? value.trim() : value;
//       const valStr = val.toString().toLowerCase();

//       let isValid = true;

//       switch (rule) {
//         case "email":
//           isValid = isValidEmail(val);
//           break;
//         case "number":
//           isValid = !isNaN(Number(val));
//           break;
//         case "boolean":
//           isValid = [
//             "true",
//             "false",
//             "1",
//             "0",
//             "yes",
//             "no",
//             "active",
//             "inactive",
//           ].includes(valStr.toLowerCase());
//           break;
//         case "url":
//           isValid = isValidURL(val);
//           break;
//         case "phone":
//           isValid = isValidPhone(val);
//           break;
//         case "string":
//           isValid = typeof val === "string" && val.trim() !== "";
//           break;
//         case "alphanumeric":
//           isValid = /^[a-z0-9]+$/i.test(valStr);
//           break;
//         case "date":
//           isValid =
//             /^\d{4}-\d{2}-\d{2}$/.test(valStr) && !isNaN(Date.parse(valStr));
//           break;
//         case "time":
//           isValid = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(valStr);
//           break;
//         case "datetime":
//           isValid = !isNaN(Date.parse(valStr));
//           break;
//         default:
//           isValid = true;
//           break;
//       }

//       if (!isValid) {
//         error[field] = `${toReadableFieldName(field)} must be a valid ${rule}.`;
//       }
//     }
//   }

//   // 3. File extension validations
//   for (const field in fileExtensionValidations) {
//     const allowedExtensions = fileExtensionValidations[field];
//     const file = formData[field];

//     if (file && file.originalname) {
//       const fileName = file.originalname.toLowerCase();
//       const fileExtension = fileName.split(".").pop() || "";
//       const isAllowed = allowedExtensions
//         .map((ext) => ext.toLowerCase())
//         .includes(fileExtension);

//       if (!isAllowed) {
//         error[field] = `${toReadableFieldName(
//           field
//         )} must be one of: ${allowedExtensions.join(", ")}.`;
//       }
//     } else if (file !== undefined) {
//       error[field] = `${toReadableFieldName(field)} must be a valid file.`;
//     }
//   }

//   const errorCount = Object.keys(error).length;

//   // Combine all field-specific messages into one string
//   const message =
//     errorCount === 0
//       ? "Form submitted successfully."
//       : Object.values(error).join(" "); // <-- here we join all errors

//   return {
//     isValid: errorCount === 0,
//     ...(errorCount > 0 && { error }),
//     message,
//   };
// }

// module.exports = { validateFormData, isValidEmail };
function toReadableFieldName(field) {
  return field
    .replace(/[-_]/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidURL(value) {
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

function isValidPhone(value) {
  return /^[\d\s()+-]{7,15}$/.test(value);
}

function validateFormData(formData, options = {}) {
  const requiredFields = options.requiredFields || [];
  const patternValidations = options.patternValidations || {};
  const fileExtensionValidations = options.fileExtensionValidations || {};
  const forbiddenFields = options.forbiddenFields || [];
  const nestedForbidden = options.nestedForbidden || {};

  const error = {};

  // 1️⃣ Required field validation (blocks empty strings)
  for (const field of requiredFields) {
    const value = formData[field];
    if (
      value === undefined ||
      value === null ||
      (typeof value === "string" && value.trim() === "")
    ) {
      error[field] = `${toReadableFieldName(field)} is required.`;
    }
  }

  // 1️⃣.5 Forbidden top-level fields
  for (const field of forbiddenFields) {
    if (formData[field] !== undefined) {
      error[field] = `${toReadableFieldName(field)} is not allowed.`;
    }
  }

  // 2️⃣ Pattern validations
  for (const field in patternValidations) {
    if (error[field]) continue; // ⛔ don’t override required error

    const rule = patternValidations[field];
    const value = formData[field];

    if (value !== undefined && value !== null) {
      const val = typeof value === "string" ? value.trim() : value;
      const valStr = val?.toString().toLowerCase();

      let isValid = true;

      switch (rule) {
        case "email":
          isValid = isValidEmail(val);
          break;
        case "number":
          isValid = val !== "" && !isNaN(Number(val));
          break;
        case "boolean":
          isValid = ["true", "false", "1", "0"].includes(valStr);
          break;
        case "url":
          isValid = isValidURL(val);
          break;
        case "phone":
          isValid = isValidPhone(val);
          break;
        case "string":
          isValid = typeof val === "string" && val.trim() !== "";
          break;
        case "alphanumeric":
          isValid = /^[a-z0-9]+$/i.test(valStr);
          break;
        case "date":
          isValid =
            /^\d{4}-\d{2}-\d{2}$/.test(valStr) && !isNaN(Date.parse(valStr));
          break;
        case "time":
          isValid = /^([01]\d|2[0-3]):[0-5]\d$/.test(valStr);
          break;
        case "datetime":
          isValid = !isNaN(Date.parse(valStr));
          break;
      }

      if (!isValid) {
        error[field] = `${toReadableFieldName(field)} must be a valid ${rule}.`;
      }
    }
  }

  // 2️⃣.5 Forbidden nested fields
  for (const [path, fields] of Object.entries(nestedForbidden)) {
    const value = formData[path];

    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        fields.forEach((field) => {
          if (item?.[field] !== undefined) {
            error[`${path}[${index}].${field}`] =
              `${toReadableFieldName(field)} is not allowed in ${toReadableFieldName(path)}.`;
          }
        });
      });
    } else if (value && typeof value === "object") {
      fields.forEach((field) => {
        if (value[field] !== undefined) {
          error[`${path}.${field}`] =
            `${toReadableFieldName(field)} is not allowed in ${toReadableFieldName(path)}.`;
        }
      });
    }
  }

  // 3️⃣ File extension validations
  for (const field in fileExtensionValidations) {
    const allowedExtensions = fileExtensionValidations[field];
    const file = formData[field];

    if (file?.originalname) {
      const ext = file.originalname.split(".").pop().toLowerCase();
      if (!allowedExtensions.map(e => e.toLowerCase()).includes(ext)) {
        error[field] =
          `${toReadableFieldName(field)} must be one of: ${allowedExtensions.join(", ")}.`;
      }
    }
  }

  const errorCount = Object.keys(error).length;

  return {
    isValid: errorCount === 0,
    ...(errorCount > 0 && { error }),
    message:
      errorCount === 0
        ? "Form submitted successfully."
        : Object.values(error).join(" "),
  };
}

module.exports = { validateFormData, isValidEmail };
