// const express = require("express");
// const router = express.Router();
// const authMiddleware = require("../../../middleware/admin/authenticate");
// // const permissionMiddleware = require("../../middleware/admin/permission");
// const {
//     sendBookingSMSToParents,
// } = require("../../../controllers/admin/booking/bookFreeTrialController");
// router.post(
//     "/weekly-classes/send-text",
//     authMiddleware,
//     // permissionMiddleware("book-free-trial", "view-listing"),
//     sendBookingSMSToParents
// );

// const {
//     sendBookingSMSToParents,
// } = require("../../../controllers/admin/booking/bookFreeTrialController");
// router.post(
//     "/weekly-classes/send-text",
//     authMiddleware,
//     // permissionMiddleware("book-free-trial", "view-listing"),
//     sendBookingSMSToParents
// );